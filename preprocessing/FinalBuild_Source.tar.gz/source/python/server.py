from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import os

class HTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        rootdir = "./files/"
        try:
            if self.path.endswith('.html'):
                f = open(rootdir + self.path)

                #send code 200 response
                self.send_response(200)

                #send header first
                self.send_header('Content-type', 'text-html')
                self.end_headers()

                #send file content to client
                self.wfile.write(f.read())
                f.close()
                return
        
        except IOError:
            self.send_error(404, 'file not found')
