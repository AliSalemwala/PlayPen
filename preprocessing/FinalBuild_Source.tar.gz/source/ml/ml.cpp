#include "ml.h"

vector <FileReport *> FileReports;
vector <CFG *> SignaturesACFG;
vector <Graph *> SignaturesGraph;

static double THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING_PASSED = 25;

ML::ML(double THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING)
{
    COMMON_CFGs = 0;
    THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING = THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING;
}

ML::~ML()
{
    for (int i = 0; i < SignaturesACFG.size(); i++)
    {
        delete (SignaturesACFG[i]);
    }
    for (int i = 0; i < SignaturesGraph.size(); i++)
    {
        delete (SignaturesGraph[i]);
    }
    SignaturesACFG.erase(SignaturesACFG.begin(), SignaturesACFG.end());
    SignaturesACFG.clear();
    SignaturesGraph.erase(SignaturesGraph.begin(), SignaturesGraph.end());
    SignaturesGraph.clear();

    for (int f = 0; f < (int)FileReports.size(); f++)
    {
        delete (FileReports[f]);
    }
    FileReports.erase(FileReports.begin(), FileReports.end());
    FileReports.clear();
}

uint64_t ML::GetDistinguishCFGs()
{
    return (SignaturesACFG.size());
}

uint64_t ML::GetCommonCFGs()
{
    return COMMON_CFGs;
}

/*
 * Save the training signatures to a file
*/

void ML::SaveACFGSignatures(string filename)
{
    vector<Block *> blocks;
    vector<BackEdge *> backEdges;
    CFG* _cfg = new CFG(blocks, backEdges, filename);
    _cfg->WriteToFile(SignaturesACFG, filename);
    printf("SignaturesACFG:%d\n%d Signatures save\n", (int)SignaturesACFG.size(), (int)SignaturesACFG.size());
    delete(_cfg);
}

/*
 * Load the training signatures from a file
*/
uint64_t ML::LoadACFGSignatures(string filename) {
    for (int i = 0; i < SignaturesACFG.size(); i++)
		delete (SignaturesACFG[i]);
	for (int i = 0; i < SignaturesGraph.size(); i++)
		delete (SignaturesGraph[i]);
	SignaturesACFG.erase(SignaturesACFG.begin(), SignaturesACFG.end());
	SignaturesACFG.clear();
	SignaturesGraph.erase(SignaturesGraph.begin(), SignaturesGraph.end());
	SignaturesGraph.clear();

    vector<Block *> blocks;
	vector<BackEdge *> backEdges;
	CFG *_cfg = new CFG(blocks, backEdges, filename);
	vector<CFG *> cfgs = _cfg->ReadFromFile(filename);
	delete(_cfg);

    //BUILD AR GRAPHS.
    IsoMorph *isom = new IsoMorph();

    for (vector<CFG* >::iterator cfgi = cfgs.begin(); cfgi != cfgs.end(); cfgi++)
    {
        CFG* cfg = *cfgi;
        
        //Build AR Graph from CFG
        Graph *g = isom->BuildGraph(cfg);
        SignaturesACFG.push_back(cfg);
        SignaturesGraph.push_back(g);
    }
    printf("%d Signatures loaded\n", (int)SignaturesACFG.size());

    delete (isom);
    return (SignaturesACFG.size());
}

void ML::BuildDataUsingGraphMatching(vector <CFG* > cfgs)
{
    IsoMorph *isom = new IsoMorph();

    for (vector <CFG *>::iterator cfgi = cfgs.begin(); cfgi != cfgs.end(); cfgi++)
    {
        CFG *cfg = *cfgi;
        Graph *g = isom->BuildGraph(cfg);
        bool MATCH = false;

        for (int s = 0; s < (int)SignaturesACFG.size(); s++)
        {
            if (isom->MatchGraphs(SignaturesGraph[s], SignaturesACFG[s], g, cfg))
            {
                COMMON_CFGs++;
                MATCH = true;
                delete(g);
                delete(cfg);
                break;
            }
        }
            if (MATCH == false)
            {
                SignaturesACFG.push_back(cfg);
                SignaturesGraph.push_back(g);
            }
    }

    printf("SignaturesACFG: %d\nSignaturesGraph: %d\n", (int)SignaturesACFG.size(), (int)SignaturesGraph.size());
    delete (isom);
}

/*
 *
 * This function creates a graph and then matches this graph
 * with the other sampled graphs (signatures). If the size
 * of the number of samples to be matched is larger, then
 * this function may take quite some time. We need to
 * optimize this function.
 */

void ML::BenignUsingGraphMatching(vector <Graph* > gs, vector <CFG* > cfgs, uint32_t filenumber)
{
    IsoMorph *isom = new IsoMorph();
    double percentageCount = 0.0;
    uint32_t totalCount = cfgs.size();
    uint32_t matchCount = 0;

    FileReports[filenumber]->simscore = percentageCount;

    for (int s = 0; s < (int)SignaturesACFG.size(); s++)
    {
        for (int c = 0; c < (int) cfgs.size(); c++)
        {
            if (isom->MatchGraphs(SignaturesGraph[s], SignaturesACFG[s], gs[c], cfgs[c]))
            {
                matchCount++;
            }
        }
        if (matchCount > 0)
		{
			percentageCount = (100.0 * matchCount) / totalCount;
			FileReports[filenumber]->simscore = percentageCount;
			if (percentageCount >= THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING_PASSED)
			{
#ifdef __PROGRAM_CFG_TRACING_OUTPUT_ENABLED__
				printf("Testing file (%s)\n", FileReports[filenumber]->filename.c_str());
				CFG *cfg_training = SignaturesACFG[s];
				printf("Training file %s\n", cfg_training->GetFilename().c_str());
				printf("Sim score: %f percent\n", FileReports[filenumber]->simscore);
#endif
				FileReports[filenumber]->benign = false;

				break;
			}
		}
        if (percentageCount >= THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING_PASSED)
			break;
    }

    delete (isom);
    return;
}
