#include "similarityDetector.h"


/*
DEfinition in ml.h
typedef struct
{
	Graph *gs;
	CFG *cfgs;
} _SignaturesACFG;

Graph *gs is an Attribute Relational Graph.
CFG *cfg is the control flow graph.
*/
extern vector<_SignaturesACFG *> Signatures;

/*
typedef struct SIGNATURE
{
	uint32_t size;
	uint32_t non_zeros;
	uint32_t *signature;
};
*/
extern vector<SIGNATURE *> MalwareSignatures;

/*
typedef struct
{
	string filename;
	uint32_t filenumber;
	bool benign;
	double simscore;
} FileReport;
*/
extern vector<FileReport *> FileReports;

SimilarityDetector::SimilarityDetector()//Parser p)
{
    //parser = p;
    total_assigning_weight_time = 0.0;
    total_training_time = 0.0;
    total_testing_time = 0.0;

    ARE_WEIGHTS_ASSIGNED = false;
}

SimilarityDetector::~SimilarityDetector() {}

void SimilarityDetector::SetThreshold(float threshold_gm)
{
	THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING = threshold_gm;
}

/*
 * ------------------------------------------------------------------------------------------------------
 *
 * SimilarityDetector::TrainDataUsingGraphMatching
 * 
 * Input Params: (1) filenames of virus_samples
 *               (2) ML* ml ?? why. Ans: The SignatureACFG and SignatureGraph
 *                      vars of ML object are populated with the cfgs of the file
 *                      and its ARGs.
 *
 * ------------------------------------------------------------------------------------------------------
 */

void SimilarityDetector::TrainDataUsingGraphMatching(string filenameP, ML* ml)
{
    /*
    ifstream : Input stream class to operate on files. Used for reading from a file.

    fileP : file pointer.
    c_str() : converts string object to c-style char array
    ios::in : Open file for reading.
    ios::binary : Binary mode.
    ios::ate : Open and seek at end. Meaning the file pointer should go to the end of file. 
    */
    ifstream fileP(filenameP.c_str(), ios::in | ios::binary | ios::ate);
    if (fileP.is_open())
    {
        /* tellg : returns the position of the pointer in the stream.
        *  Hacky way to calculate file size. 
        *   !! CHANGE THIS !!
        */
        unsigned int fileSize = (unsigned int)fileP.tellg();
        
        //return file pointer to the beginning of the file.
        fileP.seekg(0, ios::beg);
        char* fileBufferP = new char[fileSize+1];
        fileP.read(fileBufferP, fileSize);
        fileP.close();

        /* Ensures appropriate end of file.
        *  fileBuffer hold all sample names, given in the virus_sample file. 
        */
        fileBufferP[fileSize] = '\0';

        // This will hold the name of the actual virus binary.
        char filename[3*MAX_FILENAME+1];

        int c = 0;

        //Iterate over all file in sample file list.
        for (unsigned int n = 0; n < fileSize; n++)
        {
            // Why fileBufferp[n] == '\r' ??
            /* Condition:
            *  1) Havent reached end of sample file. Meaning all names have not been read.
            *  2) ??
            */
            if ( (c < 3*MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r') )
            {
                filename[c] = '\0';
                ifstream file(filename, ios::in | ios::binary | ios::ate);

                //First iteration will always fail, since filename at this point is ['\0'].
                if (file.is_open())
                {
                    // !! Find a better way to calculate size. !!
                    unsigned int size = (unsigned int)file.tellg();
                    printf("Training Data Using Graph Matching processing file: %s\n", filename);
                    fflush(stdout);

                    file.seekg(0, ios::beg);
                    char* fileBuffer = new char[size+1];
                    file.read(fileBuffer, size);
                    file.close();
                    fileBuffer[size] = '\0';

                    //Initializes Parser object.
                    Parser *parser = new Parser( (uint8_t* )fileBuffer, size);

                    /* Parses the binary file and converts x86 asm to MAIL
                    *  The parser object has a private field MAIL* mail.
                    *  It sets it to point to the mail object containing the translation of asm to mail.
                    */
                    parser->Parse(filename);

                    //See note 1 on description of BuildCFG.
                    printf("BUILDING CFGs\n");
                    vector <CFG *> cfgs = parser->BuildCFGs();

                    //See note 2.
                    ml->BuildDataUsingGraphMatching(cfgs);

                    delete(parser);
                    delete(fileBuffer);

                } 
                else cout << "Error:SimilarityDetector::TrainDataUsingGraphMatching: Cannot open the file: " << filename << "\n";

                c = 0;
                filename[c] = '\0';
                if ( n < (fileSize-1) && (fileBufferP[n+1] == '\n' || fileBufferP[n+1] == '\r'))
                    n++;
            }
            else if (c < 3*MAX_FILENAME) 
                filename[c++] = fileBufferP[n];
            else
                c = 0;
        
        }

            delete (fileBufferP);
    }
    else
        cout << "Error:SimilarityDetector::TrainDataUsingGraphMatching: Cannot open the file: " << filenameP << "\n";
    
    string filename = filenameP + "." + TRAINING_FILE_EXTENSION + ".ACFG";
    printf("Writing training file %s\n", filename.c_str());
    ml->SaveACFGSignatures(filename);
    printf("Reading training file %s\n", filename.c_str());

    //Reads from file and builds ACFG signature and AR Graphs.
    ml->LoadACFGSignatures(filename);
}

void SimilarityDetector::CheckBinariesUsingGraphMatching(string virus_samples, string files_to_check)
{
    ML* ml = new ML(THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING);

	cout << "--------------------------------------------------------------------\n";
	cout << "Train Data Using Graph Matching . . .\nVirus sample file: " << virus_samples << " . . .\n";
	cout << "--------------------------------------------------------------------\n";

    string training_filename = virus_samples + "." TRAINING_FILE_EXTENSION + ".ACFG";

    if (ml->LoadACFGSignatures(training_filename) <= 0)
        TrainDataUsingGraphMatching(virus_samples, ml);
    else
        printf("Training data read from file %s\n", training_filename.c_str());

	cout << "--------------------------------------------------------------------\n";
	cout << "Check Binaries Using Graph Matching . . .\nFiles to check file: " << files_to_check << " . . .\n";
	cout << "--------------------------------------------------------------------\n";

    ifstream fileP(files_to_check.c_str(), ios::in | ios::binary | ios::ate);
    if (fileP.is_open())
    {
        unsigned int fileSize = (unsigned int)fileP.tellg();
        fileP.seekg(0, ios::beg);
        char* fileBufferP = new char[fileSize+1];
        fileP.read(fileBufferP, fileSize);
        fileP.close();
        fileBufferP[fileSize] = '\0';

        char filename[3*MAX_FILENAME+1];
        int c = 0;
        
        uint32_t filenumber = 0;
        for (unsigned int n = 0; n < fileSize; n++)
        {
            if ((c < 3*MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
            {
                filename[c] = '\0';

                ifstream file(filename, ios::in | ios::binary | ios::ate);
                if (file.is_open())
                {
                    unsigned int size = (unsigned int)file.tellg();
                    file.seekg(0, ios::beg);
                    char* fileBuffer = new char[size + 1];
                    file.read(fileBuffer, size);
                    file.close();
                    fileBuffer[size] = '\0';

                    printf("Building Signature of %s\n", filename);
                    fflush(stdout);

                    Parser *parser = new Parser((uint8_t* )fileBuffer, size);
                    parser->Parse(filename);
                    vector <CFG* > cfgs = parser->BuildCFGs();

                    //Each Graph object corresponds to
                    //an Attribute Relational Graph of a SINGLE CFG.
                    vector <Graph *> gs;
                    IsoMorph *isom = new IsoMorph();
                    for (int c = 0; c < (int)cfgs.size(); c++)
                    {
                        Graph *g = isom->BuildGraph(cfgs[c]);
                        gs.push_back(g);
                    }
                    delete(isom);

                    FileReport *fr = new FileReport();
                    fr->filename = filename;
                    fr->filenumber = filenumber;
                    fr->benign = true;
                    FileReports.push_back(fr);

                    /*
                    * This function creates a graph and then matches this graph
                    * with the other sampled graphs (signatures).
                    */
                    ml->BenignUsingGraphMatching(gs, cfgs, filenumber);

                    if (FileReports[filenumber]->benign)
						printf("File %s is benign\n\n", filename);
					else
						printf("File %s is/contain malware\n\n", filename);
					fflush(stdout);

					filenumber++;

                    for (int c = 0; c < (int)cfgs.size(); c++)
					{
						delete (cfgs[c]);
						delete (gs[c]);
					}
					delete (parser);
					delete (fileBuffer);
                }
                else
                    cout << "Error:main: Cannot open the file: " << filename << "\n";
                
                c = 0;
                filename[c] = '\0';

                if ( n < (fileSize-1) && (fileBufferP[n+1] == '\n' || fileBufferP[n+1] == '\r') )
					n++;
            }
            else if ( c < 3*MAX_FILENAME)
                filename[c++] = fileBufferP[n];
            else
                c=0;
        }
        delete (fileBufferP);
    }
    else
		cout << "Error:SimilarityDetector::CheckBinariesUsingGraphMatching: Cannot open the file: " << files_to_check << "\n";
      
    cout << endl;
	cout << "--------------------------------------------------------------------\n";
	cout << "|                                                                  |\n";
	cout << "|                Printing Report For Graph Matching                |\n";
	cout << "|                            Files Used                            |\n";
	cout << "|                                                                  |\n";
	cout << "  1. Virus: " << virus_samples << "\n";
	cout << "  2. Check: " << files_to_check << "\n";
	cout << "|                                                                  |\n";
	cout << "| 1 and 2 were used for training and testing respectively.         |\n";
	cout << "|                                                                  |\n";
	cout << "--------------------------------------------------------------------\n";
	printf ("%180s %7s %5s %5s\n", "Filename", "Number", "Score", "Benign");
	for (unsigned int f = 0; f < FileReports.size(); f++)
	{
		//printf ("%180s %7d %5d\n", FileReports[f]->filename.c_str(), (int)FileReports[f]->filenumber, (int)FileReports[f]->benign);
		printf ("%180s %7d %5.2f %5d\n", FileReports[f]->filename.c_str(), (int)FileReports[f]->filenumber, FileReports[f]->simscore, (int)FileReports[f]->benign);
	}
	printf("\nSize of THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING = %5.5f\n", THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING);

    delete (ml);      

}