/*
 * TO DO
 * 
*/


/* Note 1 : vector <CFG* > Parser::BuildCFG()

** Additions performed in original code by me. Remove them.

This function returns an array of cfgs, corresponding to one single file.
*/
vector <CFG *> Parser::BuildCFGs()
{
#ifdef __DEBUG__
	cout << "Parser::BuildCFGs() Start\n";
#endif

	if (mail != NULL)
	{
        /*
        Each Function corresponds to a CFG, Consisting of blocks
        typedef struct Function
        {
	        char name[MAX_SYMBOL_NAME];
	        std::vector<Block *> blocks;
	        std::vector<BackEdge *> backEdges;
	        std::vector<Loop *> loops;
        };

        Each block is a collection of MAIL instructions
        typedef struct Block
        {
	        bool visited;
	        bool inLoop;
	        uint16_t type;
	        uint64_t number;
	        uint32_t function_number;
	        std::vector<Block *> prev;
	        std::vector<Edge *> edges;
	        std::vector<Edge *> in_edges;
	        std::vector<Statement *> statements;
        };
        */

		vector <Function *> functions;

        //return all the functions in the mail translation.
        //Functions consists of blocks of mail instructions.
		functions = mail->GetFunctions();

		for (int f = 0; f < (int)functions.size(); f++)
		{
			vector <Block *> blocks;
			vector <BackEdge *> backEdges;
			blocks = functions[f]->blocks;
			backEdges = functions[f]->backEdges;

            //Each function corresponds to a CFG.
			CFG *cfg = new CFG(blocks, backEdges, filename);

			
            /*
            *
            * cfg->Shrink();
            * 
            * Shrinking doesnt make sense remove for now.
            * Each block can only have one outgoing edge, 
            * since a block contains only ONE jmp or branch instr
            * Therefore, merge results in all nodes being reduced to one
            */

#ifdef __PRINT_CFG__
			cout << "\n---------------------------------------------------------------------------------------------------------\n";
			vector <Block *> blocks_cfg = cfg->GetBlocks();
			cerr << "Printing " << blocks_cfg.size() << " blocks for function number " << f << endl;
			cout << "Printing " << blocks_cfg.size() << " blocks for function number " << f << "\n\n";
			for (int bn = 0; bn < blocks_cfg.size(); bn++)
			{
				cfg->PrintBlock(blocks_cfg[bn], true);
			}
			cout << "\n---------------------------------------------------------------------------------------------------------\n";
#endif
            //Private field of Parser class.
			cfgs.push_back(cfg);

		}
#ifdef __PRINT_CFG__
			cout << "END - Printing blocks for file " << filename << " with " << functions.size() << " functions:" << "\n\n";
			cout << "\n---------------------------------------------------------------------------------------------------------\n\n\n";
#endif

	return cfgs;
}

/* Note 2 : void ML:BuildDataUsingGraphMatching

** Additions performed in original code by me. Remove them.

* This functions fills the two vectors defined in the files :-
* vector<CFG *> SignaturesACFG
* vector<Graph *> SignaturesGraph
*/

void ML::BuildDataUsingGraphMatching(vector <CFG *> cfgs)
{
	IsoMorph *isom = new IsoMorph();

    /*
    * Iterating over each CFG in a SINGLE file.
    */
	for (vector<CFG *>::iterator cfgi = cfgs.begin() ; cfgi != cfgs.end(); cfgi++)
	{
		CFG *cfg = *cfgi;

        //Build Attribute Relational Graph.
		Graph *g = isom->BuildGraph(cfg);
		bool MATCH = false;

        /* vector<CFG *> SignatureACFG
        *  Iterate over each CFG Signature.
        *  Check for match.
        *  If match, then delete the CFG passed in for testing.
        *  If no match. Add cfg to signature list.
        */
		for (int s = 0; s < (int)SignaturesACFG.size(); s++)
		{
			if (isom->MatchGraphs(SignaturesGraph[s], SignaturesACFG[s], g, cfg))
			{
				COMMON_CFGS++;
				MATCH = true;
				delete (g);
				delete (cfg);
				break;
			}
		}
		if (MATCH == false)
		{
			SignaturesACFG.push_back(cfg);
			SignaturesGraph.push_back(g);
		}
	}

   delete (isom);
}

/* Note 3 : Graph* IsoMorph::BuildGraph(CFG* cfg)
*  Returns Attribute Reltional Graph formed from the cfg given as parameter.
*/
Graph *IsoMorph::BuildGraph(CFG *cfg)
{
	ARGEdit *ed = new ARGEdit();
	vector<Block *> blocks = cfg->GetBlocks();
	for (int b = 0; b < (int)blocks.size(); b++)
	{
		ed->InsertNode(NULL);
		for (int e = 0; e < (int)blocks[b]->edges.size(); e++)
		{
			uint16_t tail = blocks[b]->edges[e]->tail->number;
			uint16_t head = blocks[b]->edges[e]->head->number;
			if (head != tail)
				ed->InsertEdge(tail, head, NULL);
		}
	}

	Graph *g = new Graph(ed);
	delete (ed);
	return (g);
}

/*
* Shrinks CFG.
*/

void CFG::Shrink()
{
	for (uint64_t b = 1; b < blocks.size(); b++)
	{
        //First in edge.
		Edge *edge = blocks[b]->in_edges[0];

        //Blocks is a private field of the CFG class.
		if (blocks[b]->number != edge->head->number)
			cerr << "Error:CFG::shrink: " << blocks[b]->number << " != " << blocks[b]->in_edges[0]->head->number << endl;
		Block *block1 = edge->tail;
		Block *block2 = blocks[b];
		if (shouldMerge(block1, block2))
		{
			merge(block1, block2, b);
			/*
			 * Delete block2
			*/
			delete (block2);
			blocks.erase(blocks.begin()+b);
			b--;
		}
	}

	for (unsigned int b = 0; b < blocks.size(); b++)
	{
		if (blocks[b]->number != b)
		{
			blocks[b]->number = b;
			/*
			 * Update the tail of outgoing edges
			 */
			for (unsigned int e = 0; e < blocks[b]->edges.size(); e++)
				blocks[b]->edges[e]->tail->number = b;
			/*
			 * Update the head of incoming edges
			 */
			for (unsigned int e = 0; e < blocks[b]->in_edges.size(); e++)
				blocks[b]->in_edges[e]->head->number = b;
		}
	}
}

/* Note 4
* vector <CFG *> cfgs = parser->BuildCFGs();
* This is what is written to the file. 
* UNDERSTAND THIS!!!
*/


/* NOTE 5 ML::BenignUsingGraphMatching
*  Parameters: (1) ARG list (2) List of CFGs (3) filenumber??
*/
void ML::BenignUsingGraphMatching(vector <Graph *> gs, vector <CFG *> cfgs, uint32_t filenumber)
{
	IsoMorph *isom = new IsoMorph();
	double percentageCount = 0.0;
    uint32_t totalCount = cfgs.size();
    uint32_t matchCount = 0;

	FileReports[filenumber]->simscore = percentageCount;
    for (int s = 0; s < (int)SignaturesACFG.size(); s++)
	{
		for (int c = 0; c < (int)cfgs.size(); c++)
		{
				if (isom->MatchGraphs(SignaturesGraph[s], SignaturesACFG[s], gs[c], cfgs[c]))
				{
#ifdef __PROGRAM_CFG_MATCH_OUTPUT_ENABLED__
					printf("|                        |\n");
					printf("| Printing Matching CFGs |\n");
					printf("|                        |\n");
					printf("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
					string filename;
					CFG *cfg_testing = cfgs[c];
					filename.assign(cfg_testing->GetFilename());
					printf("CFG from testing file (%s)\n", filename.c_str());
					vector<Block *> blocks = cfg_testing->GetBlocks();
					for (int b = 0; b < (int)blocks.size(); b++)
						cfg_testing->PrintBlock(blocks[b]);
					CFG *cfg_training = SignaturesACFG[s];
					filename.assign(cfg_training->GetFilename());
					printf("CFG from training file %s\n", filename.c_str());
					blocks = cfg_training->GetBlocks();
					for (int b = 0; b < (int)blocks.size(); b++)
						cfg_training->PrintBlock(blocks[b]);
					printf("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
#endif
					matchCount++;
				}
		}

        /*
        * Reporting Portion
        */ 
		if (matchCount > 0)
		{
			percentageCount = (100.0 * matchCount) / totalCount;
			FileReports[filenumber]->simscore = percentageCount;
			if (percentageCount >= THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING_PASSED)
			{
#ifdef __PROGRAM_CFG_TRACING_OUTPUT_ENABLED__
				printf("Testing file (%s)\n", FileReports[filenumber]->filename.c_str());
				CFG *cfg_training = SignaturesACFG[s];
				printf("Training file %s\n", cfg_training->GetFilename().c_str());
				printf("Sim score: %f percent\n", FileReports[filenumber]->simscore);
#endif
				FileReports[filenumber]->benign = false;
				break;
			}
		}
		if (percentageCount >= THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING_PASSED)
			break;
	}

	delete (isom);
	return;
}


/* TO DO NEXT
* Review the entire flow. 

* FIX CFG READ FILE SECTION.
* FIX CFG Shrinking
------------------------------

* * * Parse opcodes from disassembly
_____________________________________

* Add preprocessor directive #ifdef __ONLY_DISSASM__
* Add __ONLY_DISSASM__ as flag to make file
* Put disassemblePe function in Parser Class into public field.
* Create new class for constructing markov Chains. Put this in new folder.
* Create make file for disassembly and markov chains part.

*/



/* Write CFG to file CFG::WriteToFile

*/
void CFG::WriteToFile(vector<CFG *> cfgs, string filename)
{
	//Open file with file pointer 'file'
	ofstream file(filename.c_str(), ios::out | ios::binary | ios::app);
	if (file.is_open())
	{
		//Iterate over all CFGs
		for (vector<CFG *>::iterator cfgi = cfgs.begin() ; cfgi != cfgs.end(); cfgi++)
		{
			CFG *cfg = *cfgi;
			blocks = cfg->GetBlocks();

			file << "CFG_START\n";
			file << "(" << cfg->filename << ")\n";

			/*  Iterate over all blocks in CFG
			*	Write block type	
			*	Write function Number
			*	Iterate over Edges
			*/
			for (int b = 0; b < blocks.size(); b++)
			{
				file << "BLOCK_START\n";
				file << blocks[b]->type << "\n";
				file << blocks[b]->function_number << "\n";

				/*  Iterate over edges
				*	typedef struct Edge
					{
						bool visited;
						Block *head;
						Block *tail;
					};	

				*		
				*/
				for (int e = 0; e < (int)blocks[b]->edges.size(); e++)
				{
					//Number of the block the edge points to.
					int t = blocks[b]->edges[e]->tail->number;
					if (t != b)
					{
						cout << "Error:DroidNative:CFG::WriteToFile: Edge (tail) in Block " << b << " != " << t << " in file " << filename << "\n";
						continue;
					}
					
					// This should correspond to the number of the block. CHECK
					int h = blocks[b]->edges[e]->head->number;
					file << "EO:" << t << ":" << h << "\n";
				}
				for (int e = 0; e < (int)blocks[b]->in_edges.size(); e++)
				{
					int t = blocks[b]->in_edges[e]->tail->number;
					if (t != b)
					{
						cout << "Error:DroidNative:CFG::WriteToFile: Edge (tail) in Block " << b << " != " << t << " in file " << filename << "\n";
						continue;
					}
					int h = blocks[b]->in_edges[e]->head->number;
					file << "EI:" << t << ":" << h << "\n";
				}
				vector<Statement *> statements = blocks[b]->statements;
				for (int s = 0; s < (int)statements.size(); s++)
				{
					file << "S:" << statements[s]->offset << "\n";
					file << "S:" << statements[s]->value << "\n";
					file << "S:" << statements[s]->start << "\n";
					file << "S:" << statements[s]->end << "\n";
					file << "S:" << statements[s]->branch_to_offset  << "\n";
					file << "S:" << statements[s]->type << "\n";
				}
				file << "BLOCK_END\n";
			}
			file << "CFG_END\n";
		}
		file.close();
	}
	else
		cout << "Error:DroidNative:CFG::WriteToFile: Cannot open the file: " << filename << "\n";
}