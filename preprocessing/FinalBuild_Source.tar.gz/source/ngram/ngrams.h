#ifndef __NGRAMS_H__
#define __NGRAMS_H__

#define numStates 256

#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

class Ngrams{
	private:
		//vector<char> fileToByteArray(char const* filename);
		unsigned int fileToByteArray(char** filearr);

	public:
		string filename;
		double markovChain[numStates * numStates];
		Ngrams (char* name);
		~Ngrams();
		void makeMarkovChain();
};

#endif
