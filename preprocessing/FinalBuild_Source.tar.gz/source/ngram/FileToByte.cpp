#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

static std::vector<char> ReadAllBytes(char const* filename)
{
    ifstream ifs(filename, ios::binary|ios::ate);
    ifstream::pos_type pos = ifs.tellg();

    vector<char>  result(pos);

    ifs.seekg(0, ios::beg);
    ifs.read(&result[0], pos);
    ifs.close();

    return result;
}

int main(){
	vector<char> fileBytes = ReadAllBytes ("0703f926-9eb3-11e6-b93a-80e65024849a.file");
	int stateSize = 256;
	double markovChain[stateSize][stateSize] = {};
	int markovSums[stateSize] = {};
	unsigned int firstGram = static_cast<unsigned int> (static_cast<unsigned char> (fileBytes[0]));
	unsigned int secondGram;

	for (int i = 1; i < fileBytes.size(); i++){
		secondGram = static_cast<unsigned int>(static_cast<unsigned char> (fileBytes[i]));
		markovChain[firstGram][secondGram] += 1;
		markovSums[firstGram] += 1;

		firstGram = secondGram;
	}

	int rowSum = 0;
	for (int i = 0; i < stateSize; i++){
		double tempSum = 0;
		for (int j = 0; j < stateSize; j++){
			markovChain[i][j] = markovChain[i][j] / markovSums[i];
			//cout << markovChain[i][j] << "  ";
			tempSum += markovChain[i][j];
		}
		cout << tempSum << endl;
	}
	cout << "ALL DONE" << endl;
	return 0;
}
