#ifndef __NGRAMSDSBUILDER_H__
#define __NGRAMSDSBUILDER_H__
#define MAX_FILENAME 1024

#include "ngrams.h"
#include <vector>
#include <string>

class NgramsDatasetBuilder{
	private:
		string outname;
		char* masterFilename;
		vector<Ngrams*> collection;
		void saveSignatureData();

	public:
		NgramsDatasetBuilder (char* filename);
		~NgramsDatasetBuilder();
		void buildDataset();
};

#endif
