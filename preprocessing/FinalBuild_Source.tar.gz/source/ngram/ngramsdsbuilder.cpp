#include "ngramsdsbuilder.h"

NgramsDatasetBuilder::NgramsDatasetBuilder (char* filename){
	masterFilename = filename;
	outname = "training.ngrams";
}

NgramsDatasetBuilder::~NgramsDatasetBuilder(){
	for (vector<Ngrams *>::iterator it = collection.begin(); it != collection.end(); ++it){
		delete( *it);
	}
	collection.erase(collection.begin(), collection.end());
	collection.clear();
}

void NgramsDatasetBuilder::saveSignatureData()
{
	ofstream file(outname.c_str(), ios::out | ios::binary | ios::app);

	if (file.is_open())
	{
		for (vector<Ngrams *>::iterator it = collection.begin(); it != collection.end(); ++it)
		{
			file << "(File: " << (*it)->filename << ")" << endl;
			for (int i = 0 ; i < numStates*numStates; ++i)
			{
				file << (*it)->markovChain[i] << endl;
			}
		}
	}
	else
	{
		cout << "Error:Ngramsdsuilder:SaveSignatureData Cannot open file: " << outname << endl;
	}
}

void NgramsDatasetBuilder::buildDataset(){
	ifstream fileP(masterFilename, ios::in | ios::binary | ios::ate);
	if (fileP.is_open())
    {
        unsigned int fileSize = (unsigned int)fileP.tellg();

        fileP.seekg(0, ios::beg);
        char* fileBufferP = new char[fileSize+1];
        fileP.read(fileBufferP, fileSize);
        fileP.close();
        fileBufferP[fileSize] = '\0';

		char filename[3*MAX_FILENAME+1];
        int c = 0;

        for (unsigned int n = 0; n < fileSize; n++)
        {
            if ((c < 3*MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
            {
                filename[c] = '\0';

				Ngrams* builder = new Ngrams(filename);
				builder->makeMarkovChain();
				collection.push_back(builder);
				
				c = 0;
                filename[c] = '\0';

                if ( n < (fileSize-1) && (fileBufferP[n+1] == '\n' || fileBufferP[n+1] == '\r') )
					n++;
            }
			else if ( c < 3*MAX_FILENAME)
                filename[c++] = fileBufferP[n];
            else
                c=0;
        }
		delete[] fileBufferP;
		
		saveSignatureData();
	}
	else
	{
		cout << "Error:Ngramsdsbuilder:buildDataSet Cannot open file " << masterFilename << endl;
	}
}
