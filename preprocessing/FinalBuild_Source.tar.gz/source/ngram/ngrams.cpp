#include "ngrams.h"


Ngrams::Ngrams(char* name){
	filename = string(name);
	
	for(int i = 0; i < numStates*numStates; ++i)
	{
		markovChain[i] = 0;
	}
}

Ngrams::~Ngrams(){
}

//vector<char> Ngrams::fileToByteArray(char const* filename, char** result){
unsigned int Ngrams::fileToByteArray(char** result){  
	ifstream ifs(filename.c_str(), ios::in | ios::binary | ios::ate);

	if (ifs.is_open()) {

		unsigned int pos = ifs.tellg();
		(*result) = new char[pos];

    	ifs.seekg(0, ios::beg);
    	ifs.read(*result, pos);
    	ifs.close();

		return pos;
	}
	else
	{
		unsigned int False = static_cast<unsigned int> (-1);
		return (False);
	}
	  
}

void Ngrams::makeMarkovChain(){

	//vector<char> fileBytes = fileToByteArray (filename);
	char* fileBytes;
	unsigned int size = fileToByteArray(&fileBytes);

	unsigned int False = static_cast<unsigned int> (-1);

	if (size != False) {

		int markovSums[numStates];
		for (int i = 0; i < numStates; ++i)
		{
			markovSums[i] = 0;
		}

		unsigned int firstGram = static_cast<unsigned int>(static_cast<unsigned char>(fileBytes[0]));
		unsigned int secondGram;

		for (int i = 1; i < size; ++i)
		{
			secondGram = static_cast<unsigned int>(static_cast<unsigned char>(fileBytes[i]));

			markovChain[(firstGram * numStates) + secondGram] += 1;
			markovSums[firstGram] += 1;

			firstGram = secondGram;
		}

		delete[] fileBytes;

		for (int i = 0; i < numStates; i++)
		{
			for (int j = 0; j < numStates; j++)
			{
				markovChain[(i * numStates) + j] = markovChain[(i * numStates) + j] / markovSums[i];
			}
		}
		//cout << "Made set for " << filename << endl;
	}
	else
	{
		cout << "Error:Ngrams:makeMarkovChain Could not open file " << filename << endl;
	}
	
}
