#include "ml.h"

vector<MatchCfg *> SignaturesACFG;
vector<Graph *> SignaturesGraph;

static double THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING_PASSED = 25;

ML::ML(double THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING)
{
    COMMON_CFGs = 0;
    THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING = THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING;
}

ML::~ML()
{
    for (int i = 0; i < SignaturesACFG.size(); i++)
    {
        //Delete CFG,
        // then delete MatchCfg struct.
        delete (SignaturesACFG[i]->cfg);

        delete (SignaturesACFG[i]);
    }
    for (int i = 0; i < SignaturesGraph.size(); i++)
    {
        delete (SignaturesGraph[i]);
    }
    SignaturesACFG.erase(SignaturesACFG.begin(), SignaturesACFG.end());
    SignaturesACFG.clear();
    SignaturesGraph.erase(SignaturesGraph.begin(), SignaturesGraph.end());
    SignaturesGraph.clear();

    for (int i = 0; i < matchedCfg.size(); ++i)
    {
        delete (matchedCfg[i]);
    }

    matchedCfg.erase(matchedCfg.begin(), matchedCfg.end());
    matchedCfg.clear();


}

/*
 * Save the training signatures to a file
*/

void ML::SaveACFGSignatures(string filename)
{
    vector<Block *> blocks;
    vector<BackEdge *> backEdges;
    CFG *_cfg = new CFG(blocks, backEdges, filename);

    vector<CFG *> cfg_as_param;

    for (int i = 0; i < SignaturesACFG.size(); ++i)
    {
        cfg_as_param.push_back( SignaturesACFG[i]->cfg);
    }

    //_cfg->WriteToFile(SignaturesACFG, filename);
    _cfg->WriteToFile(cfg_as_param, filename);
    printf("SignaturesACFG:%d\n%d Signatures save\n", (int)SignaturesACFG.size(), (int)SignaturesACFG.size());
    delete (_cfg);
}

/*
 * Load the training signatures from a file
*/

uint64_t ML::LoadACFGSignatures(string filename, vector<string> &to_mactch_files)
{
    for (int i = 0; i < SignaturesACFG.size(); i++)
        delete (SignaturesACFG[i]);
    for (int i = 0; i < SignaturesGraph.size(); i++)
        delete (SignaturesGraph[i]);
    SignaturesACFG.erase(SignaturesACFG.begin(), SignaturesACFG.end());
    SignaturesACFG.clear();
    SignaturesGraph.erase(SignaturesGraph.begin(), SignaturesGraph.end());
    SignaturesGraph.clear();

    vector<Block *> blocks;
    vector<BackEdge *> backEdges;
    CFG *_cfg = new CFG(blocks, backEdges, filename);

    vector<CFG *> cfgs = _cfg->ReadFromFile(filename, to_mactch_files);
    delete (_cfg);

    //BUILD AR GRAPHS.
    IsoMorph *isom = new IsoMorph();

    int filename_counter = 0;

    for (vector<CFG *>::iterator cfgi = cfgs.begin(); cfgi != cfgs.end(); cfgi++)
    {
        CFG *cfg = *cfgi;

        //Build AR Graph from CFG
        Graph *g = isom->BuildGraph(cfg);

        // REVISIT THIS IF READFILE FAILS !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        MatchCfg *mc = new MatchCfg;
        mc->cfg = cfg;
        mc->filename = to_mactch_files[filename_counter++];

        SignaturesACFG.push_back(mc);
        SignaturesGraph.push_back(g);
    }
    printf("%d Signatures loaded\n", (int)SignaturesACFG.size());

    delete (isom);
    return (SignaturesACFG.size());
}

void ML::BuildDataUsingGraphMatching(vector<CFG *> cfgs, char *file_name)
{
    IsoMorph *isom = new IsoMorph();

    for (vector<CFG *>::iterator cfgi = cfgs.begin(); cfgi != cfgs.end(); cfgi++)
    {
        CFG *cfg = *cfgi;
        Graph *g = isom->BuildGraph(cfg);
        bool MATCH = false;

        //cout << "1) Building Graph from CFG" << endl;

        for (int s = 0; s < (int)SignaturesACFG.size(); s++)
        {
            if (isom->MatchGraphs(SignaturesGraph[s], SignaturesACFG[s]->cfg, g, cfg))
            {
                COMMON_CFGs++;
                MATCH = true;
                delete (g);
                delete (cfg);
                break;
            }
        }
        if (MATCH == false)
        {
            MatchCfg *mc = new MatchCfg;
            mc->cfg = cfg;

            string str(file_name);
            mc->filename = str;
            SignaturesACFG.push_back(mc);
            SignaturesGraph.push_back(g);
        }
    }

    //printf("SignaturesACFG: %d\nSignaturesGraph: %d\n", (int)SignaturesACFG.size(), (int)SignaturesGraph.size());
    delete (isom);
}

bool mlCfgSort(CFG *c1, CFG *c2)
{
    return (c1->GetBlocks().size() < c2->GetBlocks().size());
    //(c1.GetBlocks().size() < c2.GetBlocks().size());
}

/*
 *
 * This function creates a graph and then matches this graph
 * with the other sampled graphs (signatures). If the size
 * of the number of samples to be matched is larger, then
 * this function may take quite some time. We need to
 * optimize this function.
 */

void ML::BenignUsingGraphMatching(vector<Graph *> gs, vector<CFG *> cfgs)
{
    string current;

    IsoMorph *isom = new IsoMorph();
    uint32_t matchCount = 0;

    for (int s = 0; s < (int)SignaturesACFG.size(); s++)
    {
        for (int c = 0; c < (int)cfgs.size(); c++)
        {
            if (isom->MatchGraphs(SignaturesGraph[s], SignaturesACFG[s]->cfg, gs[c], cfgs[c]))
            {
                matchCount++;
                /*
                * vector of cfgs, per file
                * filename tracker
                * Append to vector associated with filename
                * 
                * In JSON
                * for each filename. create array of cfgs in one file.
                */
                if (current == SignaturesACFG[s]->filename)
                {
                    for (int mat = 0; mat < matchedCfg.size(); mat++)
                    {
                        if ( matchedCfg[mat]->filename == current)
                        {
                            matchedCfg[mat]->ls_cfg.push_back(cfgs[c]);
                            break;
                        }
                    }
                }
                else if (current != SignaturesACFG[s]->filename)
                {
                    JsonCfg *jc = new JsonCfg;
                    jc->filename = SignaturesACFG[s]->filename;
                    jc->ls_cfg.push_back(cfgs[c]);

                    matchedCfg.push_back(jc);

                    current = SignaturesACFG[s]->filename;
                }
                /*
                mc->cfg = cfgs[c];
                mc->filename = SignaturesACFG[s]->filename;
                matchedCfg.push_back(mc);
                */
            }
        }
    }

    for (int i = 0; i < matchedCfg.size(); ++i)
    {
        sort(matchedCfg[i]->ls_cfg.rbegin(), matchedCfg[i]->ls_cfg.rend(), mlCfgSort);
    }

    delete (isom);
    return;
}
