#include "similarityDetector.h"

/*
DEfinition in ml.h
typedef struct
{
	Graph *gs;
	CFG *cfgs;
} _SignaturesACFG;

Graph *gs is an Attribute Relational Graph.
CFG *cfg is the control flow graph.
*/
extern vector<_SignaturesACFG *> Signatures;

/*
typedef struct SIGNATURE
{
	uint32_t size;
	uint32_t non_zeros;
	uint32_t *signature;
};
*/
extern vector<SIGNATURE *> MalwareSignatures;

/*
typedef struct
{
	string filename;
	uint32_t filenumber;
	bool benign;
	double simscore;
} FileReport;
*/
extern vector<FileReport *> FileReports;

SimilarityDetector::SimilarityDetector(Parser *p)
{
    my_parser = p;
    total_assigning_weight_time = 0.0;
    total_training_time = 0.0;
    total_testing_time = 0.0;
}

SimilarityDetector::~SimilarityDetector() {}

void SimilarityDetector::SetThreshold(float threshold_gm)
{
    THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING = threshold_gm;
}
/*
bool mlCfgSort(MatchedCfg *c1, MatchedCfg *c2)
{
    return (c1->GetBlocks().size() < c2->GetBlocks().size());
    //(c1.GetBlocks().size() < c2.GetBlocks().size());
}
*/

/*
 * ------------------------------------------------------------------------------------------------------
 *
 * SimilarityDetector::TrainDataUsingGraphMatching
 * 
 *
 * ------------------------------------------------------------------------------------------------------
 */
/*
void SimilarityDetector::TrainDataUsingGraphMatching(string filenameP, ML *ml)
{

    ifstream fileP(filenameP.c_str(), ios::in | ios::binary | ios::ate);
    if (fileP.is_open())
    {
        unsigned int fileSize = (unsigned int)fileP.tellg();

        fileP.seekg(0, ios::beg);
        char *fileBufferP = new char[fileSize + 1];
        fileP.read(fileBufferP, fileSize);
        fileP.close();

        fileBufferP[fileSize] = '\0';

        char filename[3 * MAX_FILENAME + 1];

        int c = 0;

        for (unsigned int n = 0; n < fileSize; n++)
        {
            if ((c < 3 * MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
            {
                filename[c] = '\0';
                ifstream file(filename, ios::in | ios::binary | ios::ate);

                if (file.is_open())
                {
                    unsigned int size = (unsigned int)file.tellg();
                    printf("Training Data Using Graph Matching processing file: %s\n", filename);
                    fflush(stdout);

                    file.seekg(0, ios::beg);
                    char *fileBuffer = new char[size + 1];
                    file.read(fileBuffer, size);
                    file.close();
                    fileBuffer[size] = '\0';

                    //Initializes Parser object.
                    Parser *pt = new Parser((uint8_t *)fileBuffer, size);
                    pt->Parse(filename);

                    vector<CFG *> cfgs = pt->BuildCFGs();

                    //sort(cfgs.begin(), cfgs.end(), cfgSort);

                    cout << "No of CFGs: " << cfgs.size() << endl;

                    ml->BuildDataUsingGraphMatching(cfgs, filename);

                    //delete(pt);
                    delete (fileBuffer);
                }
                else
                    cout << "Error:SimilarityDetector::TrainDataUsingGraphMatching: Cannot open the file: " << filename << "\n";

                c = 0;
                filename[c] = '\0';
                if (n < (fileSize - 1) && (fileBufferP[n + 1] == '\n' || fileBufferP[n + 1] == '\r'))
                    n++;
            }
            else if (c < 3 * MAX_FILENAME)
                filename[c++] = fileBufferP[n];
            else
                c = 0;
        }

        delete (fileBufferP);
    }
    else
        cout << "Error:SimilarityDetector::TrainDataUsingGraphMatching: Cannot open the file: " << filenameP << "\n";
}
*/
void SimilarityDetector::build(vector<string> &test)
{
    //for all files in cluster. Push them to vector, and call train.
     int cluster_num = 0;

    for (vector<string>::iterator it = test.begin(); it != test.end(); ++it)
    {

        //ML *ml = new ML(THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING);

        //TrainDataUsingGraphMatching(clusters, ml, true)

        cout << "Cluster file: " << (*it) << endl;

        int num_of_files_cluster = 0;

        vector<string> list_of_cluster_files;

        ifstream fileP((*it).c_str(), ios::in | ios::binary | ios::ate);
        if (fileP.is_open())
        {
            unsigned int fileSize = (unsigned int)fileP.tellg();

            fileP.seekg(0, ios::beg);
            char *fileBufferP = new char[fileSize + 1];
            fileP.read(fileBufferP, fileSize);
            fileP.close();

            fileBufferP[fileSize] = '\0';

            char filename[3 * MAX_FILENAME + 1];

            int c = 0;

            for (unsigned int n = 0; n < fileSize; n++)
            {
                if ((c < 3 * MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
                {
                    filename[c] = '\0';

                    //num_of_files_cluster++

                    string cl_file(filename);
                    list_of_cluster_files.push_back(cl_file);

                    //Files pushed for single cluster.
                    num_of_files_cluster++;

                    c = 0;
                    filename[c] = '\0';
                    if (n < (fileSize - 1) && (fileBufferP[n + 1] == '\n' || fileBufferP[n + 1] == '\r'))
                        n++;
                }

                else if (c < 3 * MAX_FILENAME)
                    filename[c++] = fileBufferP[n];
                else
                    c = 0;
            }
        }

        cout << "Size of Cluster: " << num_of_files_cluster << endl;

        bool save = true;
        ML *ml = new ML(THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING);

        string cl = "Cluster-";

        char c_num[2];
        c_num[0] = '\0';
        sprintf(c_num, "%d", cluster_num);

        if (c_num[1] != '\0')
        {
            cl.push_back(c_num[0]);
            cl.push_back(c_num[1]);
        }
        else
        {
            cl.push_back(c_num[0]);
        }

        cl.append(".");
        cl.append(TRAINING_FILE_EXTENSION);
        cl.append(".ACFG");
        TrainDataUsingGraphMatching(list_of_cluster_files, ml, save, cl);


        // INCREMENT CLUSTER NUMBER FOR NEXT ITER
        cluster_num++;

        delete(ml);
        cout << "Files Saved: " << num_of_files_cluster << endl;
        list_of_cluster_files.erase(list_of_cluster_files.begin(), list_of_cluster_files.end());
        cout << "Cluster Erased: " << list_of_cluster_files.size() << endl;

        cout << "------------------------------------------------------------------------------------------------------\n\n";
    }
}

void SimilarityDetector::TrainDataUsingGraphMatching(vector<string> &filenameP, ML *ml, bool save, string training_filename)
{

    for (unsigned int n = 0; n < filenameP.size(); n++)
    {
        ifstream file(filenameP[n].c_str(), ios::in | ios::binary | ios::ate);

        if (file.is_open())
        {
            unsigned int size = (unsigned int)file.tellg();

            //Delete this crap!!!!
            printf("Training Data Using Graph Matching processing file: %s\n", filenameP[n].c_str());
            //////

            file.seekg(0, ios::beg);
            char *fileBuffer = new char[size + 1];
            file.read(fileBuffer, size);
            file.close();
            fileBuffer[size] = '\0';

            //Initializes Parser object.
            Parser *pt = new Parser((uint8_t *)fileBuffer, size);
            pt->Parse(filenameP[n]);

            vector<CFG *> cfgs = pt->BuildCFGs();

            //sort(cfgs.begin(), cfgs.end(), cfgSort);

            ml->BuildDataUsingGraphMatching(cfgs, filenameP[n].c_str());

            //delete(pt);
            delete (fileBuffer);
        }
        else
            cout << "Error:SimilarityDetector::TrainDataUsingGraphMatching: Cannot open the file: " << filenameP[n] << "\n";
    }

    if (save)
    {
        string filename = training_filename + "." + TRAINING_FILE_EXTENSION + ".ACFG";
        printf("Writing training file %s\n", filename.c_str());
        ml->SaveACFGSignatures(filename);
    }

    //printf("Reading training file %s\n", filename.c_str());

    //Reads from file and builds ACFG signature and AR Graphs.
    //ml->LoadACFGSignatures(filename);
}

void SimilarityDetector::CheckBinariesUsingGraphMatching(string virus_sample, vector<string> &family_members, int cluster_num, string json_output)
{
    //string json_output_fullpath(json_output);

    ML *ml = new ML(THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING);

    cout << "--------------------------------------------------------------------\n";
    cout << "Train Data Using Graph Matching . . .\nVirus sample file: " << virus_sample << " . . .\n";
    cout << "--------------------------------------------------------------------\n";

    string cl = "Cluster-";

    char c_num[2];
    c_num[0] = '\0';
    sprintf(c_num, "%d", cluster_num);

    if (c_num[1] != '\0')
    {
        cl.push_back(c_num[0]);
        cl.push_back(c_num[1]);
    }
    else
    {
        cl.push_back(c_num[0]);
    }

    cl.append(".");
    cl.append(TRAINING_FILE_EXTENSION);
    cl.append(".ACFG");
    //string training_filename = "Cluster-" + "." TRAINING_FILE_EXTENSION + ".ACFG";

    bool save = false;
    //if (ml->LoadACFGSignatures(cl, family_members) <= 0)
    TrainDataUsingGraphMatching(family_members, ml, save, cl);

    ifstream file(virus_sample.c_str(), ios::in | ios::binary | ios::ate);
    if (file.is_open())
    {
        unsigned int size = (unsigned int)file.tellg();
        file.seekg(0, ios::beg);
        char *fileBuffer = new char[size + 1];
        file.read(fileBuffer, size);
        file.close();
        fileBuffer[size] = '\0';

        cout << "Building Signature of " << virus_sample << endl;

        //Parser *parser = new Parser((uint8_t *)fileBuffer, size);
        //parser->Parse(virus_sample);

        vector<CFG *> cfgs = my_parser->BuildCFGs();

        //sort(cfgs.begin(), cfgs.end(), cfgSort);

        //Each Graph object corresponds to
        //an Attribute Relational Graph of a SINGLE CFG.
        vector<Graph *> gs;
        IsoMorph *isom = new IsoMorph();
        for (int c = 0; c < (int)cfgs.size(); c++)
        {
            Graph *g = isom->BuildGraph(cfgs[c]);
            gs.push_back(g);
        }
        delete (isom);

        /*
         * This function creates a graph and then matches this graph
         * with the other sampled graphs (signatures).
        */
        ml->BenignUsingGraphMatching(gs, cfgs);

        /*
        for (int i = 0; i < ml->matchedCfg.size(); ++i)
        {
            cout << ml->matchedCfg[i]->filename << endl;
            CFG* cfg = ml->matchedCfg[i]->cfg;
            cout << "\n---------------------------------------------------------------------------------------------------------\n";
			vector <Block *> blocks_cfg = cfg->GetBlocks();
			cerr << "Printing " << blocks_cfg.size() << " blocks" << endl;
			cout << "Printing " << blocks_cfg.size() << " blocks \n\n";
			for (int bn = 0; bn < blocks_cfg.size(); bn++)
			{
				cfg->PrintBlock(blocks_cfg[bn], true);
			}
			cout << "\n---------------------------------------------------------------------------------------------------------\n";
        }
        */

        cout << "Number of Matched CFGs: " << ml->matchedCfg.size() << endl;

        Json *j = new Json(json_output);
        for (int i = 0; i < ml->matchedCfg.size(); i++)
        {
            /*
            if (ml->matchedCfg[i]->cfg->GetBlocks().size() > SMALLEST_ACCEPTABLE_SIZE)
            {
                cout << i << ") " << "CFG size: " << ml->matchedCfg[i]->cfg->GetBlocks().size() << endl;
                j->buildJsonString(ml->matchedCfg[i]->cfg, ml->matchedCfg[i]->filename);
            }
            */
            /*
            cout << i << ") File: " << ml->matchedCfg[i]->filename << endl;
            for (int k = 0; k < ml->matchedCfg[i]->ls_cfg.size(); ++k)
            {
                cout << "   " << k << ") " << "CFG size: " << ml->matchedCfg[i]->ls_cfg[k]->GetBlocks().size() << endl;
            }
            */

            j->buildJsonString(ml->matchedCfg[i]->ls_cfg, ml->matchedCfg[i]->filename);

            /*
            for (int a = 0; a < j->j_info.size(); ++a)
            {
                for (int b = 0; b < j->j_info[a]->json_data.size(); ++b)
                {
                    cout << j->j_info[a]->json_data[b] << endl;
                }

                for (int c = 0; c < j->j_info[a]->json_edges.size(); ++c)
                {
                    cout << j->j_info[a]->json_edges[c] << endl;
                }
                cout << "\n---------------------------------------------------------------------------------------------------------\n" << endl;
            }
            */
        }

        //j->saveToFile();

        for (int c = 0; c < (int)cfgs.size(); c++)
        {
            delete (cfgs[c]);
            delete (gs[c]);
        }

        delete (fileBuffer);
        //delete (parser);
        delete (j);
    }
    else
        cout << "Error:main: Cannot open the file: " << virus_sample << "\n";

    delete (ml);
}