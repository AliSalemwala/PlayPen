#ifndef __SIMILARITY_DETECTOR_H__
#define __SIMILARITY_DETECTOR_H__

#include <unistd.h>

#include "ml.h"
#include "../parser/parser.h"
#include "../isomorph/isomorph.h"
#include "../mail/mail.h"
#include "../mail/patterns.h"
#include "../mail/signature.h"
#include "../include/swod.h"
#include "jsonConverter.h"

#define SMALLEST_ACCEPTABLE_SIZE 1

typedef struct {
    ML* ml;
    char* filename;
    char* fileBuffer;
    unsigned int size;
} ThreadData, *ThreadDataP;

using namespace std;

class SimilarityDetector
{
private:
    Parser* my_parser;
    double total_assigning_weight_time, total_training_time, total_testing_time;
    void TrainDataUsingGraphMatching(vector<string>& files_to_check, ML* ml, bool save, string training_name);
    //Parser parse;

public:
    SimilarityDetector(Parser* p);
    ~SimilarityDetector();
    void SetThreshold(float threshold_gm);
    void CheckBinariesUsingGraphMatching(string virus_samples, vector<string>& files_to_check, int cluster_num, string json_output);
    void build(vector<string>& allClusters);
};

#endif
