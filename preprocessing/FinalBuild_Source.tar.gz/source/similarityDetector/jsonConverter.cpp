#include "jsonConverter.h"

Json::Json(string file)
{
    jsonfile = file;
}

Json::~Json()
{
    /*
    for (int i = 0; i < j_info.size(); ++i)
    {
        j_info[i]->json_data.erase(j_info[i]->json_data.begin(), j_info[i]->json_data.end());
        j_info[i]->json_data.clear();

        j_info[i]->json_edges.erase(j_info[i]->json_edges.begin(), j_info[i]->json_edges.end());
        j_info[i]->json_edges.clear();

        delete (j_info[i]);
    }
*/
}

void Json::buildJsonString(vector<CFG *> ls_cfg, string outputfile) //(veCFG *cfg, string outputfile)
{
    string full_out_path(jsonfile);

    //Take filename from full path
    string temp = outputfile.substr(25);

    full_out_path.append(temp);
    full_out_path.append(".json");

    //JsonInfo *ji = new JsonInfo;
    //vector<Block *> blocks = cfg->GetBlocks();

    for (int c = 0; c < ls_cfg.size(); ++c)
    {
        JsonInfo *ji = new JsonInfo;
        vector<Block *> blocks = ls_cfg[c]->GetBlocks();

        if (blocks.size() < SMALLEST_ACCEPTABLE_SIZE)
        {
            break;
        }

        for (int i = 0; i < blocks.size(); ++i)
        {
            int block_number = blocks[i]->number;
            //build data string
            string block_str("{\"data\": {\"id\": \"b");
            string temp_block = to_string(block_number);

            block_str.append(temp_block);
            block_str.append("\", \"text\": ");

            vector<Statement *> stmt = blocks[i]->statements;
            int stmt_size = stmt.size();

            string statem = "\"";

            for (int k = 0; k < stmt_size; ++k)
            {

                //block_str.append("\"");
                //block_str.append(stmt[k]->value);
                //block_str.append("\"");
                //block_str.append("}");
                statem.append("<p>");
                statem.append(stmt[k]->value);
                statem.append("</p>");
            }
            statem.append("\"");
            block_str.append(statem);
            block_str.append("}}");
            ji->json_data.push_back(block_str);

            vector<Edge *> edges = blocks[i]->edges;
            int edges_size = edges.size();

            if (edges_size > 0)
            {
                for (int k = 0; k < edges_size; ++k)
                {
                    string edges_str("{\"data\": {\"source\": \"b");
                    edges_str.append(temp_block);
                    edges_str.append("\", \"target\": \"b");

                    int target_num = blocks[i]->edges[k]->head->number;
                    string temp_edge = to_string(target_num);
                    edges_str.append(temp_edge);

                    edges_str.append("\"}}");

                    ji->json_edges.push_back(edges_str);
                }
            }
        }

        j_info.push_back(ji);
    }

    saveToFile(full_out_path);
}

void Json::saveToFile(string saving_file)
{
    ofstream file(saving_file.c_str(), ios::out | ios::binary);

    if (file.is_open())
    {
        file << "{\"graphs\": [";
        int g_id = 1;

        int counter = 0;

        for (vector<JsonInfo *>::iterator it = j_info.begin(); it != j_info.end(); ++it)
        {
            file << "{\"g_id\": \"g";
            file << g_id++ << "\", \"nodes\": [";

            vector<string> data = (*it)->json_data;

            for (int i = 0; i < data.size(); ++i)
            {
                if (i == data.size() - 1)
                {
                    file << data[i];
                }
                else
                {
                    file << data[i] << ",";
                }
            }

            file << "],";

            vector<string> edges = (*it)->json_edges;

            file << "\"edges\": [";
            for (int i = 0; i < edges.size(); ++i)
            {
                if (i == edges.size() - 1)
                {
                    file << edges[i];
                }
                else
                {
                    file << edges[i] << ",";
                }
            }

            if (counter == j_info.size() - 1)
            {
                file << "]}";
            }
            else
            {
                file << "]},";
            }

            counter++;
        }
        file << "]}";
    }

    j_info.erase(j_info.begin(), j_info.end());
    j_info.clear();
}