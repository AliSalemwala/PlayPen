#ifndef __ML_H__
#define __ML_H__

#include <unistd.h>
#include "../cfg/cfg.h"
#include "../isomorph/argraph.h"
#include "../isomorph/argedit.h"
#include "../isomorph/isomorph.h"
#include "../mail/signature.h"

typedef struct
{
    Graph *gs;
    CFG *cfgs;
} _SignaturesACFG;

typedef struct
{
    string filename;
    uint32_t filenumber;
    bool benign;
    double simscore;
} FileReport;

typedef struct
{
    CFG *cfg;
    //vector<CFG*> ls_cfg;
    string filename;
} MatchCfg;

typedef struct
{
    //CFG *cfg;
    vector<CFG*> ls_cfg;
    string filename;
} JsonCfg;

using namespace std;

class ML
{
  private:
    uint32_t COMMON_CFGs;

  public:
    ML(double THRESHOLD_FOR_MALWARE_SAMPLE_GRAPH_MATCHING);
    ~ML();
    void BuildDataUsingGraphMatching(vector<CFG *> cfgs, char *filename);
    void BenignUsingGraphMatching(vector<Graph *> gs, vector<CFG *> cfgs);
    void SaveACFGSignatures(string filename);
    uint64_t LoadACFGSignatures(string filename, vector<string>& to_mactch_files);
    vector<JsonCfg *> matchedCfg;
};

#endif