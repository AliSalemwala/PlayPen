#ifndef __JSON_C_H__
#define __JSON_C_H__

#include <stdio.h>
#include <string.h>
#include "../include/common.h"
#include "../cfg/cfg.h"

#define SMALLEST_ACCEPTABLE_SIZE 3

struct JsonInfo
{
    vector<string> json_data;
    vector<string> json_edges;
};

class Json
{
private:
    string jsonfile;

public:
    vector<JsonInfo* > j_info;
    //void buildJsonString(CFG* cfg, string outfile);
    void buildJsonString(vector<CFG*> ls_cfg, string outfile);

    void saveToFile(string saving_file);
    Json(string file);
    ~Json();
};

#endif