#include "markovChain.h"

/*
 * TO DO
 * Bad alloc thrown. Takes too much mem. Write to file.
*/

MarkovChains::MarkovChains(Parser *p)
{
	this->num_of_opcode_mnemonics = NUMBER_OF_PATTERNS;
	parser = p;

	frequency = new double[num_of_opcode_mnemonics];
	for (int i = 0; i < num_of_opcode_mnemonics; ++i)
	{
		frequency[i] = 0;
	}

	training_filename = "training.markov";
}

MarkovChains::~MarkovChains()
{
	delete[] frequency;

	for (vector<MarkovSignature *>::iterator it = signatures.begin(); it != signatures.end(); ++it)
	{
		delete[]((*it)->sig);
		delete (*it);
	}

	signatures.erase(signatures.begin(), signatures.end());
	signatures.clear();
}

/*
void MarkovChains::buildDataSet(string samples)
{


	ifstream fileP(samples.c_str(), ios::in | ios::binary | ios::ate);
	if (fileP.is_open())
    {
        unsigned int fileSize = (unsigned int)fileP.tellg();

        fileP.seekg(0, ios::beg);
        char* fileBufferP = new char[fileSize+1];
        fileP.read(fileBufferP, fileSize);
        fileP.close();
        fileBufferP[fileSize] = '\0';

		char filename[3*MAX_FILENAME+1];
        int c = 0;

		//uint32_t filenumber = 0;

		//signatures.reserve(fileSize);
		int x = 0;

        for (unsigned int n = 0; n < fileSize; n++)
        {
            if ((c < 3*MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
            {
				filename[c] = '\0';
				//ifstream file(filename, ios::in | ios::binary | ios::ate);

				//if (file.is_open())
				//{
				//unsigned int size = (unsigned int)file.tellg();
				//file.seekg(0, ios::beg);
				//char* fileBuffer = new char[size + 1];
				//file.read(fileBuffer, size);
				//file.close();
				//fileBuffer[size] = '\0';

				cout << "Building: " << filename << endl;

				bool success = createMarkovChain(filename);

				cout << "Built: " << ++x << " " << endl;

				if (success != true)
				{

					saveSignatures();

					for (vector<MarkovSignature *>::iterator it = signatures.begin(); it != signatures.end(); ++it)
					{
						//delete( ((*it)->sig));
						delete[]((*it)->sig);
						delete (*it);
					}

					signatures.erase(signatures.begin(), signatures.end());
					signatures.clear();

					n = n - 1;
				}

				//delete[] fileBuffer;
				//}
				//else
				// cout << "Error:MarkovChains:BuildDataSet Cannot open the file: " << filename << "\n";
				c = 0;
				filename[c] = '\0';

				if (n < (fileSize - 1) && (fileBufferP[n + 1] == '\n' || fileBufferP[n + 1] == '\r'))
					n++;
			}
			else if ( c < 3*MAX_FILENAME)
                filename[c++] = fileBufferP[n];
            else
                c=0;
        }
		//delete(fileBufferP);
		delete[] fileBufferP;
	}
	else
		cout << "Error:MarkovChains::BuildDataSet: Cannot open the file: " << samples << "\n";


	saveSignatures();

}
*/
MarkovSignature *MarkovChains::createMarkovChain(string file_to_check) //const char* file_to_check)
{
	/*
	ifstream file(file_to_check.c_str(), ios::in | ios::binary | ios::ate);

    if (file.is_open())
    {
		char* fileBuffer;
        unsigned int size = (unsigned int)file.tellg();
        file.seekg(0, ios::beg);
		fileBuffer = new char[size + 1];
        file.read(fileBuffer, size);
        file.close();
        fileBuffer[size] = '\0';

		//cout << "Creating Chain For: " << file_to_check << endl;
	*/
	MarkovSignature *ms = NULL;

	try
	{
		//parser = new Parser((uint8_t* )fileBuffer, size);

		//cout << "Parser Initialized" << endl;

		//parser->Parse(file_to_check);

		//cout << "File Parsed" << endl;

		MarkovSignature *ms = populate(file_to_check.c_str());

		return ms;
	}
	catch (const std::bad_alloc &bad)
	{
		cout << "Error: " << bad.what() << " File: " << file_to_check << endl;
		return NULL;
	}

	return ms;
	;
}

void MarkovChains::resetFrequency()
{
	for (int i = 0; i < num_of_opcode_mnemonics; ++i)
	{
		frequency[i] = 0;
	}
}

void MarkovChains::saveSignatures()
{
	ofstream file(training_filename.c_str(), ios::out | ios::binary | ios::app);

	if (file.is_open())
	{

		for (vector<MarkovSignature *>::iterator it = signatures.begin(); it != signatures.end(); ++it)
		{
			file << "(File: " << (*it)->name << ")" << endl;

			for (int i = 0; i < num_of_opcode_mnemonics * num_of_opcode_mnemonics; i++)
			{
				file << (*it)->sig[i] << endl;
			}
		}

		file.close();
	}
	else
		cout << "Error:MarkovChains::SaveDistributionData: Cannot open the file: " << training_filename << "\n";
}

MarkovSignature *MarkovChains::populate(const char *filename)
{

	if (parser->mail != NULL)
	{
		//cout << "Populating" << endl;
		double *chain = new double[num_of_opcode_mnemonics * num_of_opcode_mnemonics];

		for (int i = 0; i < (num_of_opcode_mnemonics * num_of_opcode_mnemonics); ++i)
		{
			chain[i] = 0.0;
		}

		MarkovSignature *ms = new MarkovSignature;
		string str(filename);
		ms->name = str;
		ms->sig = chain;
		vector<Statement *> statements = parser->mail->GetStatements();

		int current;
		int next;
		int index;

		for (int s = 0; s < (int)statements.size() - 1; s++)
		{
			current = statements[s]->type;

			frequency[current] += 1;

			next = statements[s + 1]->type;

			index = (current * num_of_opcode_mnemonics) + next;
			ms->sig[index] += 1;
		}

		frequency[statements[(int)statements.size() - 1]->type] += 1;

		index = 0;
		for (int pattern = 0; pattern < num_of_opcode_mnemonics; pattern++)
		{
			for (int n = 0; n < num_of_opcode_mnemonics; n++)
			{
				index = (pattern * num_of_opcode_mnemonics) + n;

				if (frequency[pattern] != 0)
					ms->sig[index] = ms->sig[index] / frequency[pattern];
			}
		}

		//signatures.push_back(ms);

#ifdef __DEBUG_MARKOV__
		cout << "Markov Chain" << endl;

		int id;
		for (int i = 0; i < num_of_opcode_mnemonics; ++i)
		{
			cout << PatternsNames[i] << ": " << setw(5) << ms->sig[i * num_of_opcode_mnemonics] << " ";

			for (int j = 1; j < num_of_opcode_mnemonics; ++j)
			{
				id = (i * num_of_opcode_mnemonics) + j;
				cout << ms->sig[id] << "  ";
			}
			cout << endl;
		}

		cout << "\nFrequency Array" << endl;
		for (int i = 0; i < num_of_opcode_mnemonics; ++i)
		{
			cout << frequency[i] << " ";
		}

		int sum = 0;
		id = 0;
		cout << "\nFrequency" << endl;
		for (int i = 0; i < num_of_opcode_mnemonics; ++i)
		{
			for (int j = 0; j < num_of_opcode_mnemonics; ++j)
			{
				id = (i * num_of_opcode_mnemonics) + j;
				sum = sum + ms->sig[id];
			}
			cout << PatternsNames[i] << ": " << sum << endl;
			sum = 0;
		}
#endif

		return ms;
	}
	else
	{
		cout << "Error:MarkovChains:Populate Could not translate file " << filename << endl;
	}

	resetFrequency();
}
