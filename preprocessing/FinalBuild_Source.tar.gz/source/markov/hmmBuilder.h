#ifndef __HMM_BUILDER_H__
#define __HMM_BUILDER_H__

#include "hmm.h"
#include "../parser/parser.h"

class HMMBuilder
{
private:
    string training;
    vector<HMM* > hmm_data;
    
    void saveDistributionData();
public:
    HMMBuilder(string training);
    ~HMMBuilder();
    void buildInstrData(string family);
};

#endif