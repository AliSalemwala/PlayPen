#include "hmm.h"

/*
 * TO DO
 * Add conditional to check if instruction distribution stats are present.
 * Take number of opcodes as parameter.
 * Write instr distribution stats to file.
*/

HMM::HMM(Parser* p)
{
	parser = p;
}

HMM::~HMM()
{
	delete(parser);
}


void HMM::extractOpcodes()
{
	vector<Statement *> statements = parser->mail->GetStatements();
	for (vector<Statement *>::iterator st_it = statements.begin(); st_it != statements.end(); ++st_it)
	{
		string obs(PatternsNames[(*st_it)->type]);
		observations.push_back( obs );
	}
}