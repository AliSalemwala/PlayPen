#include "hmmBuilder.h"

HMMBuilder::HMMBuilder(string file)
{
    training = file;
}

HMMBuilder::~HMMBuilder()
{
    for(vector<HMM*>::iterator it = hmm_data.begin(); it != hmm_data.end(); ++it)
    {
        delete (*it);
    }

    hmm_data.erase(hmm_data.begin(), hmm_data.end());
    hmm_data.clear();
}


void HMMBuilder::saveDistributionData()
{
    ofstream file(training.c_str(), ios::out | ios::binary | ios::app);

    if (file.is_open())
    {
        for (vector<HMM *>::iterator it = hmm_data.begin(); it != hmm_data.end(); ++it)
        {
            for (vector<string>::iterator st_it = (*it)->observations.begin(); st_it != (*it)->observations.end(); ++st_it)
            {
                file << (*st_it) << endl;
            }
        }
    }
    else
        cout << "Error:MarkovChains::SaveDistributionData: Cannot open the file: " << training << "\n";
}

void HMMBuilder::buildInstrData(string family)
{

    ifstream fileP(family.c_str(), ios::in | ios::binary | ios::ate);
    if (fileP.is_open())
    {
        unsigned int fileSize = (unsigned int)fileP.tellg();
        fileP.seekg(0, ios::beg);
        char *fileBufferP = new char[fileSize + 1];
        fileP.read(fileBufferP, fileSize);
        fileP.close();
        fileBufferP[fileSize] = '\0';

        char filename[3 * MAX_FILENAME + 1];
        int c = 0;

        uint32_t filenumber = 0;
        for (unsigned int n = 0; n < fileSize; n++)
        {
            if ((c < 3 * MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
            {
                filename[c] = '\0';
                ifstream file(filename, ios::in | ios::binary | ios::ate);
                if (file.is_open())
                {
                    unsigned int size = (unsigned int)file.tellg();
                    file.seekg(0, ios::beg);
                    char *fileBuffer = new char[size + 1];
                    file.read(fileBuffer, size);
                    file.close();
                    fileBuffer[size] = '\0';

                    Parser *parser = new Parser((uint8_t *)fileBuffer, size);
                    parser->Parse(filename);
                    HMM *hmm = new HMM(parser);
                    hmm->extractOpcodes();

                    hmm_data.push_back(hmm);

                    cout << " File: " << filename << endl;

                    delete[] fileBuffer;
                }
                else
                    cout << "Error:main: Cannot open the file: " << filename << "\n";

                c = 0;
                filename[c] = '\0';

                if (n < (fileSize - 1) && (fileBufferP[n + 1] == '\n' || fileBufferP[n + 1] == '\r'))
                    n++;
            }
            else if (c < 3 * MAX_FILENAME)
                filename[c++] = fileBufferP[n];
            else
                c = 0;
        }
        delete[] fileBufferP;

        saveDistributionData();
        cout << "ALL COMPLETE!!!!" << endl;
    }
    else
        cout << "Error:MarkovChains::BuildInstrData: Cannot open the file: " << family << "\n";
}