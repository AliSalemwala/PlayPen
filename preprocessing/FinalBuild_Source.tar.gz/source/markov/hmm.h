#ifndef __HMM_H__
#define __HMM_H__

#include <unistd.h>
#include <sstream>
#include "../include/common.h"
#include "../parser/parser.h"
#include "../mail/patterns.h"

struct Hmm_Signature {
    unsigned int count;
    _DecodedInst *decoded;
};

using namespace std;

class HMM
{
private:
    Parser* parser;

public:
    vector<string> observations; 
    HMM(Parser* p);
    ~HMM();
    void extractOpcodes();
};

#endif