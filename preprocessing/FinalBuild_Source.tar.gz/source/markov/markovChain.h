#ifndef __MARKOV_CHAIN_H__
#define __MARKOV_CHAIN_H__

#include <unistd.h>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include "sys/types.h"
#include "sys/sysinfo.h"
#include "../include/common.h"
#include "../mail/patterns.h"
#include "../parser/parser.h"

struct Mnemonic_info {
    std::string m;
    int count;
};

struct MarkovSignature {
    string name;
    double* sig;
};

using namespace std;

class MarkovChains
{
private:
    double* frequency;
    //int* frequency;
    vector<MarkovSignature* > signatures;
    int num_of_opcode_mnemonics;
    Parser* parser;
    string training_filename;

    MarkovSignature* populate(const char* filename);
    void resetFrequency();
    void saveSignatures();

public:
    MarkovChains(Parser* p);
    ~MarkovChains();
    MarkovSignature* createMarkovChain(string filename);//const char* file_to_check);
    //void buildDataSet(string samples);
};

#endif