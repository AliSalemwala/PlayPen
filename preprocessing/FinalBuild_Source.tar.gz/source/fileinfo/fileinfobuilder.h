#ifndef __FILEINFOBUILDER_H__
#define __FILEINFOBUILDER_H__
#define MAX_FILENAME 1024

#include <vector>
#include <string>

#include "fileinfo.h"

using namespace std;

class FileDatasetBuilder{
	private:
		string outname;
		char* masterFilename;
		vector<FileInfo* > collection;
		void saveSignatureData();

	public:
		FileDatasetBuilder (const char* filename);
		~FileDatasetBuilder();
		void buildDataset();
};

#endif
