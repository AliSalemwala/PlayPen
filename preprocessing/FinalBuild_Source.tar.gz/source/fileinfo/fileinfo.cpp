#include "fileinfo.h"

FileInfo::FileInfo(char* name, Parser* p)
{
    std::string str(name);
    filename = str;
    parser = p;
}

FileInfo::~FileInfo()
{
}

void FileInfo::getVerticesAndEdges(double* vertices, double* edges)
{
    vector<Function*> f = parser->mail->GetFunctions();

    for (vector<Function* >::iterator fit = f.begin(); fit != f.end(); fit++)
    {
        (*vertices) += (*fit)->blocks.size();

        for (vector<Block* >::iterator bit = (*fit)->blocks.begin(); bit != (*fit)->blocks.end(); bit++ )
        {
            (*edges) += (*bit)->edges.size();
        }
    }
}

double FileInfo::entropyAnalysis(uint8_t* buffer, unsigned int size)
{
    int POSSIBLE_BYTES = 256;
    double entropy = 0.0;

    double total = size * 8.0;

    double base = 1/log(POSSIBLE_BYTES);

    unsigned int byteCount[POSSIBLE_BYTES];

    for (int i = 0; i < POSSIBLE_BYTES; ++i)
    {
        byteCount[i] = 0;
    }

    for (int byte = 0; byte < size; ++byte)
    {
        byteCount[ (int)buffer[ byte] ] += 1;
    }

    double prob = 0.0;


    for (int count = 0; count < POSSIBLE_BYTES; ++count)
    {
        prob = 1.0 * (double(byteCount[count]) / total);

        if (prob != 0)
        {
            entropy -= (prob * (log(prob)/base) );
        }
    }

    //cout << entropy<< endl;

    return entropy;
}
/*
 * Calculates the following information about a file
 * Entropy.
 * Size.
 * Number of vertices in CFG.
 * Number of edges in CFG.
 * Number of Instructions.
*/

void FileInfo::constructFeatureVector()
{
    ifstream file(filename.c_str(), ios::in | ios::binary | ios::ate);

    //cout << filename.c_str();
    if (file.is_open())
    {
		uint8_t* fileBuffer;
        unsigned int size = (unsigned int)file.tellg();
        file.seekg(0, ios::beg);
		fileBuffer = new uint8_t[size + 1];
        file.read(fileBuffer, size);
        file.close();
        fileBuffer[size] = '\0';

        //save size
        information[FILE_SIZE] = size;

        //save Vertices and Edges.
        double vertices = 0.0;
        double edges = 0.0;
        getVerticesAndEdges(&vertices, &edges);

        information[NUMBER_OF_VERTICES_CFG] = vertices;
        information[NUMBER_OF_EDGES_CFG]    = edges;

        //number of instructions
        double instrs = static_cast<double> (parser->mail->GetStatements().size());
        information[NUMBER_OF_INSTRUCTIONS] = instrs;

        //Calculate Entropy;
        double entropy = entropyAnalysis(fileBuffer, size);
        information[ENTROPY] = entropy;
        
        delete[] fileBuffer;

#ifdef __DEBUG_FI__
        for (int i = 0; i < 5; ++i)
        {
            cout << information[i] << " ";
        }
        cout << endl;
#endif
        
    }
    else
        cout << "Error:FileInfo:ConstructFeatureVector Cannot open the file: " << filename << "\n";
}