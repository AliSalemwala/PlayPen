#include "fileinfobuilder.h"

FileDatasetBuilder::FileDatasetBuilder (const char* filename){
	masterFilename = filename;
	outname = "training.fileinfo";
}

FileDatasetBuilder::~FileDatasetBuilder(){
	for (vector<FileInfo *>::iterator it = collection.begin(); it != collection.end(); ++it){
		delete( *it);
	}
	collection.erase(collection.begin(), collection.end());
	collection.clear();
}

void FileDatasetBuilder::saveSignatureData()
{
	ofstream file(outname.c_str(), ios::out | ios::binary | ios::app);

	if (file.is_open())
	{
		for (vector<FileInfo *>::iterator it = collection.begin(); it != collection.end(); ++it)
		{
			file << "(File: " << (*it)->filename << ")" << endl;
			for (int i = 0 ; i < VECTOR_SIZE; ++i)
			{
				file << (*it)->information[i] << endl;
			}
		}
	}
	else
	{
		cout << "Error:FileInfoBuilder:SaveSignatureData Cannot open file: " << outname << endl;
	}
}

void FileDatasetBuilder::buildDataset(){
	ifstream fileP(masterFilename, ios::in | ios::binary | ios::ate);
	if (fileP.is_open())
    {
        unsigned int fileSize = (unsigned int)fileP.tellg();

        fileP.seekg(0, ios::beg);
        char* fileBufferP = new char[fileSize+1];
        fileP.read(fileBufferP, fileSize);
        fileP.close();
        fileBufferP[fileSize] = '\0';

		char filename[3*MAX_FILENAME+1];
        int c = 0;

        for (unsigned int n = 0; n < fileSize; n++)
        {
            if ((c < 3*MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
            {
                filename[c] = '\0';
				ifstream file(filename, ios::in | ios::binary | ios::ate);

				string filenamestr(filename);

				if (file.is_open())
				{
				    unsigned int size = (unsigned int)file.tellg();
				    file.seekg(0, ios::beg);
				    char* fileBuffer = new char[size + 1];
				    file.read(fileBuffer, size);
				    file.close();
				    fileBuffer[size] = '\0';

                    Parser* parser = new Parser((uint8_t* )fileBuffer, size);

                    parser->Parse(filenamestr);


                    FileInfo* fi = new FileInfo(filename, parser);
                    fi->constructFeatureVector();
					//fi->entropyAnalysis(fileBuffer, size);
	

                    collection.push_back(fi);

					delete(parser);
				
                    delete[] fileBuffer;
				}
				else
				    cout << "Error:FileInfoBuilder:BuildDataSet Cannot open the file: " << filename << "\n";
				c = 0;
                filename[c] = '\0';

                if ( n < (fileSize-1) && (fileBufferP[n+1] == '\n' || fileBufferP[n+1] == '\r') )
					n++;
            }
			else if ( c < 3*MAX_FILENAME)
                filename[c++] = fileBufferP[n];
            else
                c=0;
        }
		delete[] fileBufferP;
		
		saveSignatureData();
	}
	else
	{
		cout << "Error:FileInfoBuilder:buildDataSet Cannot open file " << masterFilename << endl;
	}
}
