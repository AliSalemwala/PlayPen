#ifndef __FI_INFO__
#define __FI_INFO__

#include <vector>
#include <fstream>
#include <iostream>
#include <math.h>

#include "../parser/parser.h"
#include "../include/common.h"

#define VECTOR_SIZE 5

enum Feature {
    FILE_SIZE, 
    NUMBER_OF_VERTICES_CFG, 
    NUMBER_OF_EDGES_CFG, 
    NUMBER_OF_INSTRUCTIONS, 
    ENTROPY
};

using namespace std;

class FileInfo {
    
private:
    Parser* parser;
	int fileToByteArray(char** filearr);
    void getVerticesAndEdges(double* vertices, double* edges);

public:
    string filename;
    double information[VECTOR_SIZE];

	double entropyAnalysis(uint8_t* buffer,  unsigned int size);
    void constructFeatureVector();

    FileInfo(char* name, Parser* p);
    ~FileInfo();
};

#endif