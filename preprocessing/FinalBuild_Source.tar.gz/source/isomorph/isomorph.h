#ifndef __ISOMORPH_H__
#define __ISOMORPH_H__

#include "../cfg/cfg.h"
#include "argraph.h"
#include "argedit.h"
#include "vf2_sub_state.h"
#include "match.h"

#define THRESHOLD_FOR_MALWARE_NODE_MATCHING_OUT_OF_100      90
#define STATEMENTS_DIFF_LIMIT_FOR_PATTERN_MATCHING          0
#define MAX_NODES                                           65535

using namespace std;

/**
 * <p>
 *
 * This class implements the IsoMorph class.
 * It checks the two control flow graphs (CFGs)
 * for matching (isomorphism). If one of the graphs
 * is a smaller graph then it checks for the subgraph
 * matching (isomorphism).
 */

class IsoMorph
{
private:
    bool patternMatch(Block *b1, Block *b2);
    void findPattern(Statement *stmt);

public:
    IsoMorph();
    ~IsoMorph();
    bool MatchGraphs(CFG *cfg1, CFG* cfg2);
    bool MatchGraphs(Graph *g1, CFG *cfg1, Graph *g2, CFG *cfg2);
    Graph *BuildGraph(CFG *cfg);
};

#endif