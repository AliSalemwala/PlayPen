#include <iostream>
#include <fstream>
#include <sstream>
#include <iterator>
#include <string>
#include <stdint.h>
#include <time.h>
#include <openssl/md5.h>
#include <chrono>
#include <ctime>
#include <boost/lexical_cast.hpp>

#include "similarityDetector/ml.h"
#include "similarityDetector/similarityDetector.h"
#include "parser/parser.h"
#include "isomorph/isomorph.h"
#include "mail/mail.h"
#include "mail/patterns.h"
#include "include/swod.h"
#include "markov/markovChain.h"
#include "markov/hmm.h"
#include "markov/hmmBuilder.h"
#include "ngram/ngramsdsbuilder.h"
#include "ngram/ngrams.h"
#include "fileinfo/fileinfo.h"
#include "fileinfo/fileinfobuilder.h"
#include "k-graphlets/kg.h"
#include "fdetection/buildFamilyTree.h"

using namespace std;

#define NGRAM_STATES 256
#define FILE_INFORMATION_VECTOR_SIZE 5
#define FAMILY_SIZE 10
#define FILENAME_LENGTH_DATASET 512

string make_md5(string filename)
{
	string md5sum;
	int n;
	MD5_CTX c;
	char buf[MAX_FILENAME_LENGTH];
	ssize_t bytes = MAX_FILENAME_LENGTH;
	unsigned char out[MD5_DIGEST_LENGTH];

	MD5_Init(&c);
	MD5_Update(&c, filename.c_str(), filename.length());

	MD5_Final(out, &c);

	char md5_output[3];
	for (n = 0; n < MD5_DIGEST_LENGTH; n++)
	{
		sprintf(md5_output, "%02x", out[n]);

		string str_temp(md5_output);
		md5sum.append(str_temp);
	}

	return md5sum;
}

int main(int argc, char **argv, char **envp)
{

#ifdef __PREDICT__

	if (argc == 2)
	{

		int FILE_SIZE_INDEX = 0;
		int ENTROPY_INDEX = 4;

		//name to save.
		string md5_sum_virus_file_csv;
		string md5_sum_virus_file_json;

		//Pathnames
		string alerts = "./logs/alerts/alerts";
		string csv_fullpath = "./logs/phylogeny/fdetection/";
		string cfg_json_fullpath = "./logs/phylogeny/cfg/";

		// Ngram var. Pre processed it wrong. Use incorrect number of states for now.
		double *ngram_chains; //[NGRAM_STATES * NGRAM_STATES];

		// Markov var.
		MarkovSignature *m_sig = NULL;

		//File Info var.
		FileInfo *fi = NULL;
		double *file_information; //[FILE_INFORMATION_VECTOR_SIZE];

		//Combined Array. !! WITHOUT FILE INFO. AND INCORRECT NUM_OF_STATES IN NGRAM_CHAIN !!
		int combined_size = (NUMBER_OF_PATTERNS * NUMBER_OF_PATTERNS) + NGRAM_STATES; // NOTES its should be: (NUMBER_OF_PATTERNS * NUMBER_OF_PATTERNS) + (NGRAM_STATES * NGRAM_STATES). FIX WITH NEW MODEL
		string combined_str;

		// NAME of file being checked.
		string file_to_check;
		file_to_check.assign(argv[1]);

		ifstream file(file_to_check.c_str(), ios::in | ios::binary | ios::ate);

		// Test Sample file data collection.
		if (file.is_open())
		{
			char *fileBuffer;
			unsigned int size = (unsigned int)file.tellg();
			file.seekg(0, ios::beg);
			fileBuffer = new char[size + 1];
			file.read(fileBuffer, size);
			file.close();
			fileBuffer[size] = '\0';

			Parser *parser = new Parser((uint8_t *)fileBuffer, size);
			parser->Parse(file_to_check);

			//Build Markov Chains
			MarkovChains *mc;
			mc = new MarkovChains(parser);

			m_sig = mc->createMarkovChain(file_to_check);

			//Build Ngram
			Ngrams *ng = new Ngrams(file_to_check.c_str());
			ng->makeMarkovChain();
			ngram_chains = ng->markovChain;

			//Build File Info
			fi = new FileInfo(file_to_check.c_str(), parser);
			fi->constructFeatureVector();
			file_information = fi->information;

			//Build Argument for model script.
			for (int markov = 0; markov < NUMBER_OF_PATTERNS * NUMBER_OF_PATTERNS; ++markov)
			{
				std::ostringstream strs;
				strs << m_sig->sig[markov];
				std::string dbl = strs.str();

				combined_str.append(dbl);
				combined_str.append(" ");
			}

			for (int ngram = 0; ngram < NGRAM_STATES; ++ngram)
			{
				std::ostringstream strs;
				strs << ngram_chains[ngram];
				std::string dbl = strs.str();

				combined_str.append(dbl);
				combined_str.append(" ");
			}

			//Calling Model Script
			string command = "python3 ./machine_learning/model/model_cli.py --predict ";
			command.append(combined_str);

			FILE *in = popen(command.c_str(), "r");
			int res;
			fscanf(in, "%d", &res);
			pclose(in);

			cout << res << endl;

			//Write md5Sum and timestamp to file, IF RESULT IS 1.
			if (res)
			{
				ofstream file(alerts.c_str(), ios::out | ios::binary | ios::app);

				if (file.is_open())
				{	

					file << file_to_check << " ";
					
					string md5sum;

					md5sum = make_md5(file_to_check);
					
					cout << "Md5sum of file: " << md5sum << endl;
					file << md5sum << " ";

					md5_sum_virus_file_csv.append(md5sum);
					md5_sum_virus_file_json.append(md5sum);

					//Appending pathname
					md5_sum_virus_file_csv.append(".csv");
					md5_sum_virus_file_json.append("/");

					auto start = std::chrono::system_clock::now();
					auto end = std::chrono::system_clock::now();

					std::chrono::duration<double> elapsed_seconds = end - start;

					std::time_t end_time = std::chrono::system_clock::to_time_t(end);

					file << file_information[ENTROPY_INDEX];
					file << " ";
					file << file_information[FILE_SIZE_INDEX];
					file << " ";

					file << std::ctime(&end_time);
				}
			}

			//Run Phylogeny, IF RES IS 1
			if (res)
			{
				/*
				* Run k-means clustering
				*/

				//Build Command.
				string kmeans_combined_str;
				string command_clustering = "python3 ./machine_learning/knn/kmeans-cli.py --predict "; //./model-cli/model-cli/model_cli.py --predict ";

				for (int markov = 0; markov < NUMBER_OF_PATTERNS * NUMBER_OF_PATTERNS; ++markov)
				{
					std::ostringstream strs;
					strs << m_sig->sig[markov];
					std::string dbl = strs.str();

					kmeans_combined_str.append(dbl);
					kmeans_combined_str.append(" ");
				}

				command_clustering.append(kmeans_combined_str);

				int cluster_predicted;

				//Run kmeans script
				FILE *in2 = popen(command_clustering.c_str(), "r");
				char kmeans_closest[FAMILY_SIZE * FILENAME_LENGTH_DATASET];
				kmeans_closest[0] = '\0';
				fscanf(in2, "%s", kmeans_closest);
				//fscanf(in2, "%s", kmeans_closest);
				pclose(in2);

				//Read Detected Cluster.

				//Read family names and distances.
				cluster_predicted = (kmeans_closest[0]) - '0';
				cout << "Cluster Prediction: " << cluster_predicted << endl;

				//Parse Python result. Results are family member names (10), and distances (10)
				char *remaining = &kmeans_closest[2];
				string python_files_list(remaining);

				std::stringstream ss(python_files_list);

				char delim = ':';
				string token;
				vector<string> files_and_dist;

				char danger[1] = {'\n'};
				while (getline(ss, token, delim))
				{
					files_and_dist.push_back(token);
				}

				vector<string> family;
				double distances[FAMILY_SIZE];

				//Build family vector and distance array.
				for (int file = 0; file < FAMILY_SIZE; ++file)
				{
					family.push_back(files_and_dist[file]);
					distances[file] = atof(files_and_dist[file + FAMILY_SIZE].c_str());
				}

				//Build CSV File, for Family tree construction.
				csv_fullpath.append(md5_sum_virus_file_csv);
				//cout << csv_fullpath << endl;
				BuildTree *build_tree = new BuildTree(family, distances, FAMILY_SIZE);
				build_tree->makeCsvFile(csv_fullpath);

				//Run SubGraph Isomorphism.
				SimilarityDetector *sd = new SimilarityDetector(parser);
				sd->SetThreshold(0);

				string dir_cmd = "mkdir ";
				cfg_json_fullpath.append(md5_sum_virus_file_json);
				dir_cmd.append(cfg_json_fullpath);
				system(dir_cmd.c_str());

				sd->CheckBinariesUsingGraphMatching(file_to_check, family, cluster_predicted, cfg_json_fullpath);

				cout << "ALL COMPETE" << endl;

				delete (sd);
				delete (build_tree);
			}
			else
			{
				cout << "Error:PlayPen:Main Could not open alerts file" << endl;
			}

			//delete objects.
			delete (fileBuffer);
			delete (parser);
			delete (mc);
			delete (ng);
			delete (fi);
		}
		else
		{
			cout << "Usage for running Predict: Predict <file_to_check>\n";
		}
	}

#endif

	/*
#ifdef __TEST_READ__

	if (argc == 3)
	{
		vector<string> to_match;


		//Give file containing all clusters 
		string matching_name;
		matching_name.assign(argv[1]);

		ifstream fileP(matching_name.c_str(), ios::in | ios::binary | ios::ate);
		if (fileP.is_open())
		{
			unsigned int fileSize = (unsigned int)fileP.tellg();

			fileP.seekg(0, ios::beg);
			char *fileBufferP = new char[fileSize + 1];
			fileP.read(fileBufferP, fileSize);
			fileP.close();

			fileBufferP[fileSize] = '\0';

			char filename[3 * MAX_FILENAME + 1];

			int c = 0;

			for (unsigned int n = 0; n < fileSize; n++)
			{
				if ((c < 3 * MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
				{
					filename[c] = '\0';

					string file_str(filename);

					//pushing name of cluster. Cluster-i
					to_match.push_back(file_str);

					c = 0;
					filename[c] = '\0';
					if (n < (fileSize - 1) && (fileBufferP[n + 1] == '\n' || fileBufferP[n + 1] == '\r'))
						n++;
				}
				else if (c < 3 * MAX_FILENAME)
					filename[c++] = fileBufferP[n];
				else
					c = 0;
			}
		}

		string training;
		training.assign(argv[2]);

		ML* ml = new ML(0.0);

		uint64_t size = ml->LoadACFGSignatures(training, to_match);

		cout << "Files to match: " << to_match.size() << endl;

		cout << "Files read: " << size << endl;

		delete(ml);
	}

#endif

#ifdef __TRAIN_ACFG_DATA__

	if (argc == 2)
	{
		vector<string> clusters;


		//Give file containing all clusters 
		string filenameP;
		filenameP.assign(argv[1]);

		ifstream fileP(filenameP.c_str(), ios::in | ios::binary | ios::ate);
		if (fileP.is_open())
		{
			unsigned int fileSize = (unsigned int)fileP.tellg();

			fileP.seekg(0, ios::beg);
			char *fileBufferP = new char[fileSize + 1];
			fileP.read(fileBufferP, fileSize);
			fileP.close();

			fileBufferP[fileSize] = '\0';

			char filename[3 * MAX_FILENAME + 1];

			int c = 0;

			for (unsigned int n = 0; n < fileSize; n++)
			{
				if ((c < 3 * MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
				{
					filename[c] = '\0';

					string file_str(filename);

					//pushing name of cluster. Cluster-i
					clusters.push_back(file_str);

					c = 0;
					filename[c] = '\0';
					if (n < (fileSize - 1) && (fileBufferP[n + 1] == '\n' || fileBufferP[n + 1] == '\r'))
						n++;
				}
				else if (c < 3 * MAX_FILENAME)
					filename[c++] = fileBufferP[n];
				else
					c = 0;
			}
		}

		SimilarityDetector *sd = new SimilarityDetector( NULL);
		sd->build(clusters);

	}


#endif
*/

	/*
#ifdef __RUN_ACFG__
	//
	// For graph signature (ACFG) matching
	//
	if (argc == 3)
	{
		cout << "Starting" << endl;

		string virus_sample, files_to_check;

		// Training malware samples
		virus_sample.assign(argv[1]);
		// Files to be checked and tagged as malware/benign
		files_to_check.assign(argv[2]);

		vector<string> testV;

		ifstream fileP(files_to_check.c_str(), ios::in | ios::binary | ios::ate);
		if (fileP.is_open())
		{
			unsigned int fileSize = (unsigned int)fileP.tellg();

			fileP.seekg(0, ios::beg);
			char *fileBufferP = new char[fileSize + 1];
			fileP.read(fileBufferP, fileSize);
			fileP.close();

			fileBufferP[fileSize] = '\0';

			char filename[3 * MAX_FILENAME + 1];

			int c = 0;

			for (unsigned int n = 0; n < fileSize; n++)
			{
				if ((c < 3 * MAX_FILENAME) && (fileBufferP[n] == '\n' || fileBufferP[n] == '\r'))
				{
					filename[c] = '\0';
					string vir(filename);
					testV.push_back(filename);

					c = 0;
					filename[c] = '\0';
					if (n < (fileSize - 1) && (fileBufferP[n + 1] == '\n' || fileBufferP[n + 1] == '\r'))
						n++;
				}
				else if (c < 3 * MAX_FILENAME)
					filename[c++] = fileBufferP[n];
				else
					c = 0;
			}
			delete (fileBufferP);
		}

		SimilarityDetector *sd = new SimilarityDetector();
		sd->SetThreshold(0);
		sd->CheckBinariesUsingGraphMatching(virus_sample, testV);
		delete (sd);
	}
#endif
*/
	/*
#ifdef __HMM__
	if (argc == 2)
	{
		string samples;
		samples.assign(argv[1]);
		HMMBuilder *hb = new HMMBuilder("test.hmm");
		hb->buildInstrData(samples);

		delete (hb);
	}
#endif
*/
	/*
#ifdef __MARKOV_CHAINS__

	if (argc == 2)
	{
		string file_to_check;
		file_to_check.assign(argv[1]);

		ifstream file(file_to_check.c_str(), ios::in | ios::binary | ios::ate);

		if (file.is_open())
		{
			char *fileBuffer;
			unsigned int size = (unsigned int)file.tellg();
			file.seekg(0, ios::beg);
			fileBuffer = new char[size + 1];
			file.read(fileBuffer, size);
			file.close();
			fileBuffer[size] = '\0';

			Parser *parser = new Parser((uint8_t *)fileBuffer, size);
			parser->Parse(file_to_check);

			MarkovChains *mc;
			mc = new MarkovChains(parser);

			MarkovSignature *ms = NULL;
			ms = mc->createMarkovChain(file_to_check);

			int num_of_opcode_mnemonics = NUMBER_OF_PATTERNS;

			if (ms != NULL)
			{
				cout << "Markov Chain" << endl;

				int id;
				for (int i = 0; i < num_of_opcode_mnemonics; ++i)
				{
					cout << PatternsNames[i] << ": " << setw(5) << ms->sig[i * num_of_opcode_mnemonics] << " ";

					for (int j = 1; j < num_of_opcode_mnemonics; ++j)
					{
						id = (i * num_of_opcode_mnemonics) + j;
						cout << ms->sig[id] << "  ";
					}
					cout << endl;
				}
			}
			else
			{
				cout << "MS is null" << endl;
			}

			delete[] ms->sig;
			delete (ms);
			delete(parser);
			
		}
		else
			cout << "Error:main: Cannot open the file: " << file_to_check << "\n";
	}
#endif
*/
	/*
#ifdef __HMM__

	if (argc == 2)
	{
		string file_to_check;
		file_to_check.assign(argv[1]);
		HMM *hmm = new HMM(file_to_check);
		hmm->test();
	}
#endif

*/

	/*
#ifdef __NGRAM__
	if (argc == 2)
	{
		char *filename = argv[1];
		NgramsDatasetBuilder* b = new NgramsDatasetBuilder(filename);
		b->buildDataset();
		delete b;
	}
#endif
*/

	/*
#ifdef __FI__
	if (argc == 2)
	{
		string file_to_check;
		file_to_check.assign(argv[1]);
		
		FileDatasetBuilder* fi = new FileDatasetBuilder(file_to_check.c_str());
		fi->buildDataset();

		delete fi;
	}
#endif
*/
	/*
#ifdef __KG__
	if (argc == 2) {
		string to_check;
		to_check.assign(argv[1]);

		ifstream file(to_check, ios::in | ios::binary | ios::ate);
		Parser* parser;

		if (file.is_open())
    	{	
			char* fileBuffer;
        	unsigned int size = (unsigned int)file.tellg();
        	file.seekg(0, ios::beg);
			fileBuffer = new char[size + 1];
        	file.read(fileBuffer, size);
        	file.close();
        	fileBuffer[size] = '\0';

			parser = new Parser((uint8_t* )fileBuffer, size);

			//parser->Parse(to_check);
			KGraphlet* kg = new KGraphlet(parser, 5, to_check);
			kg->test();

			//delete(parser);
			//delete[] fileBuffer;
		}
	}
#endif
*/
	/*
#ifdef __PRINT_ONLY_MAIL__
	//
	// For testing and debugging and printing MAIL statements
	//
	else if (argc == 2)
	{
		string filename;
		filename.assign(argv[1]);


		 * Open binary file for reading with the file pointer pointing at the end (ate)
		ifstream file(filename.c_str(), ios::in | ios::binary | ios::ate);
		if (file.is_open())
		{
			unsigned int fileSize = (unsigned int)file.tellg();                // How much buffer we need for the file
			file.seekg (0, ios::beg);
			char *fileBuffer = new char[fileSize+1];
			file.read(fileBuffer, fileSize);                                  // Read the file into the buffer
			file.close();
			fileBuffer[fileSize] = '\0';

			Parser *parser = new Parser((uint8_t *)fileBuffer, fileSize);
			parser->Parse(filename);
			vector <CFG *> cfgs = parser->BuildCFGs();
			for (int c = 0; c < (int)cfgs.size(); c++)
				delete (cfgs[c]);
			delete (parser);
			delete (fileBuffer);
		}
		else
			cout << "Error:DroidNative:main: Cannot open the file: " << filename << "\n";
	}
#endif
	else
	{
		cout << "Error:DroidNative:main: Wrong parameters.\n";
		cout << "The program does not check for the correctness and order of parameters.\n";
		cout << "It's the responsibility of the user to provide correct parameters in order provided below.\n";
#ifdef __PRINT_ONLY_MAIL__
		cout << "Usage: DroidNative <filename>\n";
#else
		cout << "Usage for running ACFG: DroidNative <max_threads> <threshold_gm> <virus_samples> <file_to_check>\n";
		cout << "Usage for running SWOD: DroidNative <max_threads> <vwod> <hwod> <threshold_vwod> <threshold_hwod> <threshold_vsd> <threshold_hsd> <malware_samples> <benign_samples> <virus_samples> <file_to_check>\n";
#endif
	}

	*/

	return 0;
}
