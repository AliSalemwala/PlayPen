#include "kg.h"

KGraphlet::KGraphlet(Parser *p, int k, string name)
{
    graphletSize = k;
    parser = p;
    filename = name;

    parser->Parse(filename);
    blocks = parser->mail->GetBlocks();

    cout << "Final blocks: " << blocks.size() << endl;

    int count = 0;
    int zeroes = 0;
    int singles = 0;
    for (int i = 0; i < blocks.size(); ++i)
    {
        if (blocks[i]->edges.size() == 2)
        {
            count++;
        }
        if (blocks[i]->edges.size() == 0)
        {
            zeroes++;
        }
        if (blocks[i]->edges.size() == 1)
        {
            singles++;
        }
    }

    cout << "Found " << count << " parents." << endl;
    cout << "Found " << zeroes << " lonelies." << endl;
    cout << "Found " << singles << " singles." << endl;
}

void KGraphlet::test()
{
   
    int c = 0;

    for (vector<Block *>::iterator it = blocks.begin(); it != blocks.end(); ++it)
    {
        if ((*it)->edges.size() != 0)
        {

            Span_Tree *root_st = new Span_Tree;
            root_st->root = *it;

            kDFS(root_st);
        }
    }

    for( const auto& n : kg ) {
        std::cout << "Key:[" << n.first << "] Value:[" << n.second << "]\n";
    }
}

void KGraphlet::kDFS(Span_Tree *root)
{
    //int children_of_root = root->root->edges.size()
    int tree_size_poss = pow(2, graphletSize) - 1;
    //int all_permutations = 8 * tree_size_poss;

    char bitmap[tree_size_poss][SIG_PATTERN_SIZE];

    for (int i = 0; i < tree_size_poss; ++i)
    {
        bitmap[i][0] = '\0';
    }

    char signatures[graphletSize * 2 + 1];
    signatures[0] = '\0';

    int all_children[tree_size_poss];
    for (int i = 0; i < tree_size_poss; ++i)
    {
        all_children[i] = -1;
    }

    DFS(root, 0, bitmap, all_children, 0);
    createAllSigs(bitmap, all_children, signatures, 0, 0);

}

int KGraphlet::count_sig(char *signature)
{
    int c = 0;
    int count = 0;
    while (signature[c] != '\0')
    {
        if (signature[c] == '1')
        {
            count++;
        }
        c++;
    }

    return count;
}

void KGraphlet::saveSig(char *signature)
{

   string str(signature);
   auto s = kg.find(str);
   if ( s != kg.end())
   {
       kg[str] += 1;
   }
   else
   {
       kg[str] = 1;
       cout << signature << endl;
   }
   
}


void KGraphlet::createAllSigs(char (*bitmap)[SIG_PATTERN_SIZE], int *children, char *signature, int mark, int curr_node)
{

    char *marker;
    int offset_to_left;
    int offset_to_right;
    int local_mark = mark;

    for (int i = 0; i < SIG_PATTERN_SIZE - 1; i = i + 2)
    {
        marker = &(bitmap[curr_node][i]);

        if (*marker == '\0')
        {
            int count = count_sig(signature);

            if (count == (graphletSize - 1))
            {
                //save signature;
                saveSig(signature);
            }
        }

        else if (*marker == '0' && *(++marker) == '0')
        {

            int count = count_sig(signature);

            if (count == (graphletSize - 1))
            {
                //save signature;
                saveSig(signature);
            }
        }
        else if (*marker == '1' && *(++marker) == '0')
        {
            int temp = local_mark;
            signature[temp++] = '1';
            signature[temp] = '0';
            signature[temp+1] = '\0';

            offset_to_left = (2 * curr_node) + 1;

            createAllSigs(bitmap, children, signature, temp+1, offset_to_left); //local_mark + 1, offset_to_left);
            //local_mark = mark;
        }
        else if (*marker == '0' && *(++marker) == '1')
        {
            int temp = local_mark;
            signature[temp++] = '0';
            signature[temp] = '1';
            signature[temp+1] = '\0';

            offset_to_right = (2 * curr_node) + 2;

            createAllSigs(bitmap, children, signature, temp+1, offset_to_right); //local_mark + 1, offset_to_right);
            //local_mark = mark;
        }
        else if ((*marker == '1' && *(++marker) == '1'))
        {

            int temp = local_mark;
            signature[temp++] = '1';
            signature[temp] = '1';
            signature[temp+1] = '\0';


            offset_to_right = (2 * curr_node) + 2;
            offset_to_left = (2 * curr_node) + 1;

            createAllSigs(bitmap, children, signature, temp+1, offset_to_left); //local_mark + 1, offset_to_left);
            //local_mark = mark;
            createAllSigs(bitmap, children, signature, temp+1, offset_to_right); //local_mark + 1, offset_to_right);
            //local_mark = mark;
        }
    }
}

int KGraphlet::DFS(Span_Tree *next, int depth, char (*bitmap)[SIG_PATTERN_SIZE], int *all_children, int curr_node)
{
    int children_size = next->root->edges.size();
    int left_children = 0;
    depth++;

    if ((depth < graphletSize) && (children_size != 0))
    {
        int node_id_left = (2 * curr_node) + 1;
        int node_id_right = (2 * curr_node) + 2;
        next->root->st_visited = true;

        Block *left = next->root->edges[0]->head;

        if (children_size == 2)
        {
            Block *right = next->root->edges[1]->head;

            if (!(right->st_visited) && !(left->visited))
            {
                //Initialize left child node.
                Span_Tree *c_left = new Span_Tree;
                c_left->root = left;

                //Assign left child.
                next->left = c_left;

                //Initialize right child node.
                Span_Tree *c_right = new Span_Tree;
                c_right->root = next->root->edges[1]->head;

                //Assign right child.
                next->right = c_right;

                strcat(bitmap[curr_node], "00100111");
                DFS(c_left, depth, bitmap, all_children, node_id_left);
                DFS(c_right, depth, bitmap, all_children, node_id_right);

                all_children[curr_node] = 2;
            }
            else if (!(right->st_visited) && left->st_visited)
            {
                //Assume right child to be left child.

                //Initialize left child node. Use right block.

                Span_Tree *c_right = new Span_Tree;
                c_right->root = right;

                next->right = c_right;

                next->left = NULL;

                //strcat(bitmap, "00000100");
                strcat(bitmap[curr_node], "00000100");
                DFS(c_right, depth, bitmap, all_children, node_id_left);
                all_children[curr_node] = 1;

            }
            else if (!(left->st_visited) && right->st_visited)
            {
                //Initialize left child node.
                Span_Tree *c_left = new Span_Tree;
                c_left->root = left;

                //Assign left child.
                next->left = c_left;

                next->right = NULL;

                strcat(bitmap[curr_node], "00100000");
                DFS(c_left, depth, bitmap, all_children, node_id_right);
                all_children[curr_node] = 1;
            }
        }
        else if (children_size == 1 && !(left->st_visited))
        {
            Block *left = next->root->edges[0]->head;

            //Initialize left child node.
            Span_Tree *c_left = new Span_Tree;
            c_left->root = left;

            //Assign left child.
            next->left = c_left;

            next->right = NULL;

            strcat(bitmap[curr_node], "00100000");
            DFS(c_left, depth, bitmap, all_children, node_id_left);
            all_children[curr_node] = 1;
        }
        else
        {
            next->left = NULL;
            next->right = NULL;
        }
    }
    else
    {
        next->left = NULL;
        next->right = NULL;
    }

    return left_children;
}
