#ifndef __KG_H__
#define __KG_H__

#include <stdio.h>
#include <math.h>
#include <unordered_map>

#include "../parser/parser.h"
#include "../include/common.h"
#include "../cfg/cfg.h"
#include "../mail/mail.h"

#define SIG_PATTERN_SIZE 9

struct Span_Tree {
    Block* root;
    struct Span_Tree* left;
    struct Span_Tree* right;
    int capacity;
};

struct KgSig {
    string sig;
    int freq;
};

class KGraphlet
{
private:
    int graphletSize;
    Parser* parser;
    string filename;

    vector<Block *> blocks;
    unordered_map<string, int> kg;
    
    void kDFS(Span_Tree* root);
    int DFS(Span_Tree* next, int depth, char (*bitmap)[SIG_PATTERN_SIZE], int* all_children, int curr_node);
    void createAllSigs(char (*bitmap)[SIG_PATTERN_SIZE], int *children, char *signature, int mark, int curr_node);
    void saveSig(char* sig);

    int count_sig(char *signature);

public:
    KGraphlet(Parser* p, int k, string name);
    ~KGraphlet();
    void test();
};

#endif