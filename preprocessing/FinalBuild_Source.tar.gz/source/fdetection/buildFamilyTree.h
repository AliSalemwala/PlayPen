#ifndef __BUILD_TREE_H__
#define __BUILD_TREE_H__

#include <string>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

class BuildTree
{
private:
    vector<string> family;
    double* distances;
    int FAMILY_SIZE;

public:
    BuildTree(vector<string>& family, double* distances, int size);
    ~BuildTree();

    makeCsvFile(string test_file_name);
};

#endif