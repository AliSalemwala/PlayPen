#include "buildFamilyTree.h"

BuildTree::BuildTree(vector<string>& fam, double* dist, int size)
{
    family = fam;
    distances = dist;

    FAMILY_SIZE = size;

}

BuildTree::~BuildTree()
{
}

BuildTree::makeCsvFile(string filename)
{
    string csv_file = filename;

    ofstream file(csv_file.c_str(), ios::out | ios::binary);

    if (file.is_open())
    {
        file << "value,name" << endl;

        for (int i = 0; i < FAMILY_SIZE; ++i)
        {
            file << distances[i] << "," << family[i] << endl;
        }
    }
}